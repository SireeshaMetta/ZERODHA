import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { UserModel, IUserDocument } from '../models/User.ts';
import { HoldingModel, IHoldingDocument } from '../models/Holding.ts';
import { OrderModel, IOrderDocument } from '../models/Order.ts';
import { TransactionModel, ITransactionDocument } from '../models/Transaction.ts';
import { WatchlistModel, IWatchlistDocument } from '../models/Watchlist.ts';
import { Holding, Order, Transaction, User, WatchlistGroup } from '../../src/types/index.ts';

// In-memory / persistent mock storage structure for zero-dependency operation
interface LocalStorageData {
  users: Map<string, User & { passwordHash: string }>;
  holdings: Map<string, Holding[]>; // userId -> holdings
  orders: Map<string, Order[]>; // userId -> orders
  transactions: Map<string, Transaction[]>; // userId -> transactions
  watchlists: Map<string, WatchlistGroup[]>; // userId -> watchlists
}

const memoryStore: LocalStorageData = {
  users: new Map(),
  holdings: new Map(),
  orders: new Map(),
  transactions: new Map(),
  watchlists: new Map(),
};

let mongoConnected = false;

export async function initStorage(): Promise<void> {
  const uri = process.env.MONGODB_URI;
  if (uri && uri !== '') {
    try {
      await mongoose.connect(uri, { serverSelectionTimeoutMS: 2000 });
      mongoConnected = true;
      console.log('Successfully connected to MongoDB.');
    } catch (err) {
      console.warn('MongoDB connection failed or not available. Using TradeX High-Performance Local Storage Engine.');
      mongoConnected = false;
    }
  } else {
    console.log('TradeX running with In-Memory Hybrid Storage Engine (MongoDB URI optional in .env)');
  }

  // Seed default demo user into memoryStore
  seedDefaultDemoData();
}

function seedDefaultDemoData() {
  const demoUserId = 'usr_demo_zerodha';
  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync('password123', salt);

  const demoUser: User & { passwordHash: string } = {
    id: demoUserId,
    name: 'Metta Sireesha',
    email: 'demo@tradex.com',
    passwordHash,
    clientCode: 'TX9082',
    virtualCash: 852400.50,
    initialCash: 1000000,
    usedMargin: 0,
    createdAt: new Date('2026-01-15T09:15:00.000Z').toISOString(),
  };

  memoryStore.users.set(demoUserId, demoUser);
  memoryStore.users.set('demo@tradex.com', demoUser);

  // Seed initial holdings for realistic portfolio view
  const demoHoldings: Holding[] = [
    {
      id: 'hld_1',
      userId: demoUserId,
      symbol: 'RELIANCE',
      stockName: 'Reliance Industries Ltd',
      quantity: 25,
      averagePrice: 2860.00,
      investedValue: 71500.00,
      currentPrice: 2942.50,
      currentValue: 73562.50,
      unrealizedPnL: 2062.50,
      unrealizedPnLPercent: 2.88,
      dayPnL: 602.50,
      dayPnLPercent: 0.83,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'hld_2',
      userId: demoUserId,
      symbol: 'INFY',
      stockName: 'Infosys Ltd',
      quantity: 40,
      averagePrice: 1810.00,
      investedValue: 72400.00,
      currentPrice: 1872.40,
      currentValue: 74896.00,
      unrealizedPnL: 2496.00,
      unrealizedPnLPercent: 3.45,
      dayPnL: 940.00,
      dayPnLPercent: 1.27,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'hld_3',
      userId: demoUserId,
      symbol: 'HDFCBANK',
      stockName: 'HDFC Bank Ltd',
      quantity: 30,
      averagePrice: 1650.00,
      investedValue: 49500.00,
      currentPrice: 1684.20,
      currentValue: 50526.00,
      unrealizedPnL: 1026.00,
      unrealizedPnLPercent: 2.07,
      dayPnL: 702.00,
      dayPnLPercent: 1.41,
      updatedAt: new Date().toISOString(),
    },
  ];
  memoryStore.holdings.set(demoUserId, demoHoldings);

  // Seed demo completed orders
  const demoOrders: Order[] = [
    {
      id: 'ord_101',
      orderId: 'TX-ORD-9021',
      userId: demoUserId,
      symbol: 'RELIANCE',
      stockName: 'Reliance Industries Ltd',
      side: 'BUY',
      product: 'CNC',
      type: 'MARKET',
      quantity: 25,
      price: 2860.00,
      executedPrice: 2860.00,
      status: 'COMPLETED',
      statusMessage: 'Order fully executed at ₹2,860.00',
      createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
      executedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    },
    {
      id: 'ord_102',
      orderId: 'TX-ORD-9022',
      userId: demoUserId,
      symbol: 'INFY',
      stockName: 'Infosys Ltd',
      side: 'BUY',
      product: 'CNC',
      type: 'MARKET',
      quantity: 40,
      price: 1810.00,
      executedPrice: 1810.00,
      status: 'COMPLETED',
      statusMessage: 'Order fully executed at ₹1,810.00',
      createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      executedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    },
    {
      id: 'ord_103',
      orderId: 'TX-ORD-9023',
      userId: demoUserId,
      symbol: 'HDFCBANK',
      stockName: 'HDFC Bank Ltd',
      side: 'BUY',
      product: 'CNC',
      type: 'MARKET',
      quantity: 30,
      price: 1650.00,
      executedPrice: 1650.00,
      status: 'COMPLETED',
      statusMessage: 'Order fully executed at ₹1,650.00',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      executedAt: new Date(Date.now() - 86400000).toISOString(),
    },
  ];
  memoryStore.orders.set(demoUserId, demoOrders);

  // Seed demo transactions
  const demoTransactions: Transaction[] = [
    {
      id: 'txn_101',
      userId: demoUserId,
      orderId: 'TX-ORD-9021',
      symbol: 'RELIANCE',
      stockName: 'Reliance Industries Ltd',
      side: 'BUY',
      product: 'CNC',
      quantity: 25,
      price: 2860.00,
      totalAmount: 71500.00,
      timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
    },
    {
      id: 'txn_102',
      userId: demoUserId,
      orderId: 'TX-ORD-9022',
      symbol: 'INFY',
      stockName: 'Infosys Ltd',
      side: 'BUY',
      product: 'CNC',
      quantity: 40,
      price: 1810.00,
      totalAmount: 72400.00,
      timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
    },
    {
      id: 'txn_103',
      userId: demoUserId,
      orderId: 'TX-ORD-9023',
      symbol: 'HDFCBANK',
      stockName: 'HDFC Bank Ltd',
      side: 'BUY',
      product: 'CNC',
      quantity: 30,
      price: 1650.00,
      totalAmount: 49500.00,
      timestamp: new Date(Date.now() - 86400000).toISOString(),
    },
  ];
  memoryStore.transactions.set(demoUserId, demoTransactions);

  // Seed watchlists
  const demoWatchlists: WatchlistGroup[] = [
    {
      id: 1,
      name: 'NIFTY 50 Bluechips',
      symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN'],
    },
    {
      id: 2,
      name: 'Auto & Infra',
      symbols: ['TATAMOTORS', 'LT', 'MARUTI'],
    },
    {
      id: 3,
      name: 'Consumer & Retail',
      symbols: ['ITC', 'TITAN', 'BAJFINANCE'],
    },
    {
      id: 4,
      name: 'Tech & Telecom',
      symbols: ['TCS', 'INFY', 'BHARTIARTL'],
    },
    {
      id: 5,
      name: 'Custom Watchlist',
      symbols: ['RELIANCE', 'SBIN', 'TITAN'],
    },
  ];
  memoryStore.watchlists.set(demoUserId, demoWatchlists);
}

export const StorageEngine = {
  isMongoActive(): boolean {
    return mongoConnected && mongoose.connection.readyState === 1;
  },

  getStorageStatus() {
    const isMongo = StorageEngine.isMongoActive();
    return {
      mode: isMongo ? 'MongoDB Cluster' : 'High-Performance Local Hybrid Store',
      isMongoConnected: isMongo,
      database: isMongo ? mongoose.connection.name : 'tradex_local_store',
    };
  },

  async getUserByEmail(email: string): Promise<(User & { passwordHash: string }) | null> {
    const normalized = email.toLowerCase().trim();
    if (StorageEngine.isMongoActive()) {
      const doc = await UserModel.findOne({ email: normalized });
      if (!doc) return null;
      return {
        id: doc._id.toString(),
        name: doc.name,
        email: doc.email,
        passwordHash: doc.passwordHash,
        clientCode: doc.clientCode,
        virtualCash: doc.virtualCash,
        initialCash: doc.initialCash,
        usedMargin: doc.usedMargin,
        createdAt: doc.createdAt.toISOString(),
      };
    }
    return memoryStore.users.get(normalized) || null;
  },

  async getUserById(id: string): Promise<User | null> {
    if (StorageEngine.isMongoActive()) {
      const doc = await UserModel.findById(id);
      if (!doc) return null;
      return {
        id: doc._id.toString(),
        name: doc.name,
        email: doc.email,
        clientCode: doc.clientCode,
        virtualCash: doc.virtualCash,
        initialCash: doc.initialCash,
        usedMargin: doc.usedMargin,
        createdAt: doc.createdAt.toISOString(),
      };
    }
    const user = memoryStore.users.get(id);
    if (!user) return null;
    const { passwordHash: _, ...rest } = user;
    return rest;
  },

  async createUser(data: { name: string; email: string; passwordHash: string }): Promise<User> {
    const normalized = data.email.toLowerCase().trim();
    const clientCode = 'TX' + Math.floor(1000 + Math.random() * 9000);
    const initialCash = 1000000;

    if (StorageEngine.isMongoActive()) {
      const doc = await UserModel.create({
        name: data.name,
        email: normalized,
        passwordHash: data.passwordHash,
        clientCode,
        virtualCash: initialCash,
        initialCash,
        usedMargin: 0,
      });
      return {
        id: doc._id.toString(),
        name: doc.name,
        email: doc.email,
        clientCode: doc.clientCode,
        virtualCash: doc.virtualCash,
        initialCash: doc.initialCash,
        usedMargin: doc.usedMargin,
        createdAt: doc.createdAt.toISOString(),
      };
    }

    const newUser: User & { passwordHash: string } = {
      id: 'usr_' + Date.now(),
      name: data.name,
      email: normalized,
      passwordHash: data.passwordHash,
      clientCode,
      virtualCash: initialCash,
      initialCash,
      usedMargin: 0,
      createdAt: new Date().toISOString(),
    };

    memoryStore.users.set(newUser.id, newUser);
    memoryStore.users.set(normalized, newUser);
    memoryStore.holdings.set(newUser.id, []);
    memoryStore.orders.set(newUser.id, []);
    memoryStore.transactions.set(newUser.id, []);
    memoryStore.watchlists.set(newUser.id, [
      { id: 1, name: 'Watchlist 1', symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY'] },
      { id: 2, name: 'Watchlist 2', symbols: ['ICICIBANK', 'SBIN', 'TATAMOTORS'] },
      { id: 3, name: 'Watchlist 3', symbols: ['ITC', 'LT', 'BAJFINANCE', 'TITAN'] },
      { id: 4, name: 'Watchlist 4', symbols: [] },
      { id: 5, name: 'Watchlist 5', symbols: [] },
    ]);

    const { passwordHash: _, ...rest } = newUser;
    return rest;
  },

  async updateUserCash(userId: string, cashDelta: number, marginDelta = 0): Promise<User | null> {
    if (StorageEngine.isMongoActive()) {
      const doc = await UserModel.findByIdAndUpdate(
        userId,
        { $inc: { virtualCash: cashDelta, usedMargin: marginDelta } },
        { new: true }
      );
      if (!doc) return null;
      return {
        id: doc._id.toString(),
        name: doc.name,
        email: doc.email,
        clientCode: doc.clientCode,
        virtualCash: doc.virtualCash,
        initialCash: doc.initialCash,
        usedMargin: doc.usedMargin,
        createdAt: doc.createdAt.toISOString(),
      };
    }

    const user = memoryStore.users.get(userId);
    if (!user) return null;
    user.virtualCash = Number((user.virtualCash + cashDelta).toFixed(2));
    user.usedMargin = Math.max(0, Number((user.usedMargin + marginDelta).toFixed(2)));
    return user;
  },

  async resetUserFunds(userId: string): Promise<User | null> {
    if (StorageEngine.isMongoActive()) {
      const doc = await UserModel.findByIdAndUpdate(
        userId,
        { virtualCash: 1000000, usedMargin: 0 },
        { new: true }
      );
      if (!doc) return null;
      await HoldingModel.deleteMany({ userId });
      await OrderModel.deleteMany({ userId });
      await TransactionModel.deleteMany({ userId });
      return {
        id: doc._id.toString(),
        name: doc.name,
        email: doc.email,
        clientCode: doc.clientCode,
        virtualCash: doc.virtualCash,
        initialCash: doc.initialCash,
        usedMargin: doc.usedMargin,
        createdAt: doc.createdAt.toISOString(),
      };
    }

    const user = memoryStore.users.get(userId);
    if (!user) return null;
    user.virtualCash = 1000000;
    user.usedMargin = 0;
    memoryStore.holdings.set(userId, []);
    memoryStore.orders.set(userId, []);
    memoryStore.transactions.set(userId, []);
    return user;
  },

  async getHoldings(userId: string): Promise<Holding[]> {
    if (StorageEngine.isMongoActive()) {
      const docs = await HoldingModel.find({ userId });
      return docs.map((d) => ({
        id: d._id.toString(),
        userId: d.userId,
        symbol: d.symbol,
        stockName: d.stockName,
        quantity: d.quantity,
        averagePrice: d.averagePrice,
        investedValue: d.investedValue,
        currentPrice: d.averagePrice, // Will be enriched with live price
        currentValue: d.investedValue,
        unrealizedPnL: 0,
        unrealizedPnLPercent: 0,
        dayPnL: 0,
        dayPnLPercent: 0,
        updatedAt: d.updatedAt.toISOString(),
      }));
    }
    return memoryStore.holdings.get(userId) || [];
  },

  async getHolding(userId: string, symbol: string): Promise<Holding | null> {
    const holdings = await StorageEngine.getHoldings(userId);
    return holdings.find((h) => h.symbol === symbol) || null;
  },

  async saveHolding(holding: Holding): Promise<void> {
    if (StorageEngine.isMongoActive()) {
      await HoldingModel.findOneAndUpdate(
        { userId: holding.userId, symbol: holding.symbol },
        {
          symbol: holding.symbol,
          stockName: holding.stockName,
          quantity: holding.quantity,
          averagePrice: holding.averagePrice,
          investedValue: holding.investedValue,
          updatedAt: new Date(),
        },
        { upsert: true, new: true }
      );
      return;
    }

    const userHoldings = memoryStore.holdings.get(holding.userId) || [];
    const idx = userHoldings.findIndex((h) => h.symbol === holding.symbol);
    if (idx >= 0) {
      if (holding.quantity <= 0) {
        userHoldings.splice(idx, 1);
      } else {
        userHoldings[idx] = holding;
      }
    } else if (holding.quantity > 0) {
      userHoldings.push(holding);
    }
    memoryStore.holdings.set(holding.userId, userHoldings);
  },

  async deleteHolding(userId: string, symbol: string): Promise<void> {
    if (StorageEngine.isMongoActive()) {
      await HoldingModel.deleteOne({ userId, symbol });
      return;
    }
    const userHoldings = memoryStore.holdings.get(userId) || [];
    const filtered = userHoldings.filter((h) => h.symbol !== symbol);
    memoryStore.holdings.set(userId, filtered);
  },

  async getOrders(userId: string): Promise<Order[]> {
    if (StorageEngine.isMongoActive()) {
      const docs = await OrderModel.find({ userId }).sort({ createdAt: -1 });
      return docs.map((d) => ({
        id: d._id.toString(),
        orderId: d.orderId,
        userId: d.userId,
        symbol: d.symbol,
        stockName: d.stockName,
        side: d.side,
        product: d.product,
        type: d.type,
        quantity: d.quantity,
        price: d.price,
        triggerPrice: d.triggerPrice,
        executedPrice: d.executedPrice,
        status: d.status,
        statusMessage: d.statusMessage,
        createdAt: d.createdAt.toISOString(),
        executedAt: d.executedAt ? d.executedAt.toISOString() : undefined,
      }));
    }
    return memoryStore.orders.get(userId) || [];
  },

  async getOrderById(orderId: string): Promise<Order | null> {
    if (StorageEngine.isMongoActive()) {
      const d = await OrderModel.findOne({ orderId });
      if (!d) return null;
      return {
        id: d._id.toString(),
        orderId: d.orderId,
        userId: d.userId,
        symbol: d.symbol,
        stockName: d.stockName,
        side: d.side,
        product: d.product,
        type: d.type,
        quantity: d.quantity,
        price: d.price,
        triggerPrice: d.triggerPrice,
        executedPrice: d.executedPrice,
        status: d.status,
        statusMessage: d.statusMessage,
        createdAt: d.createdAt.toISOString(),
        executedAt: d.executedAt ? d.executedAt.toISOString() : undefined,
      };
    }

    for (const orders of memoryStore.orders.values()) {
      const match = orders.find((o) => o.orderId === orderId || o.id === orderId);
      if (match) return match;
    }
    return null;
  },

  async createOrder(order: Order): Promise<Order> {
    if (StorageEngine.isMongoActive()) {
      const doc = await OrderModel.create({
        orderId: order.orderId,
        userId: order.userId,
        symbol: order.symbol,
        stockName: order.stockName,
        side: order.side,
        product: order.product,
        type: order.type,
        quantity: order.quantity,
        price: order.price,
        triggerPrice: order.triggerPrice,
        executedPrice: order.executedPrice,
        status: order.status,
        statusMessage: order.statusMessage,
        createdAt: new Date(order.createdAt),
        executedAt: order.executedAt ? new Date(order.executedAt) : undefined,
      });
      return { ...order, id: doc._id.toString() };
    }

    const userOrders = memoryStore.orders.get(order.userId) || [];
    userOrders.unshift(order);
    memoryStore.orders.set(order.userId, userOrders);
    return order;
  },

  async updateOrder(orderId: string, updates: Partial<Order>): Promise<Order | null> {
    if (StorageEngine.isMongoActive()) {
      const doc = await OrderModel.findOneAndUpdate(
        { orderId },
        { ...updates, executedAt: updates.executedAt ? new Date(updates.executedAt) : undefined },
        { new: true }
      );
      if (!doc) return null;
      return {
        id: doc._id.toString(),
        orderId: doc.orderId,
        userId: doc.userId,
        symbol: doc.symbol,
        stockName: doc.stockName,
        side: doc.side,
        product: doc.product,
        type: doc.type,
        quantity: doc.quantity,
        price: doc.price,
        triggerPrice: doc.triggerPrice,
        executedPrice: doc.executedPrice,
        status: doc.status,
        statusMessage: doc.statusMessage,
        createdAt: doc.createdAt.toISOString(),
        executedAt: doc.executedAt ? doc.executedAt.toISOString() : undefined,
      };
    }

    for (const [userId, orders] of memoryStore.orders.entries()) {
      const idx = orders.findIndex((o) => o.orderId === orderId || o.id === orderId);
      if (idx >= 0) {
        orders[idx] = { ...orders[idx], ...updates };
        memoryStore.orders.set(userId, orders);
        return orders[idx];
      }
    }
    return null;
  },

  async getTransactions(userId: string): Promise<Transaction[]> {
    if (StorageEngine.isMongoActive()) {
      const docs = await TransactionModel.find({ userId }).sort({ timestamp: -1 });
      return docs.map((d) => ({
        id: d._id.toString(),
        userId: d.userId,
        orderId: d.orderId,
        symbol: d.symbol,
        stockName: d.stockName,
        side: d.side,
        product: d.product,
        quantity: d.quantity,
        price: d.price,
        totalAmount: d.totalAmount,
        realizedPnL: d.realizedPnL,
        timestamp: d.timestamp.toISOString(),
      }));
    }
    return memoryStore.transactions.get(userId) || [];
  },

  async createTransaction(txn: Transaction): Promise<Transaction> {
    if (StorageEngine.isMongoActive()) {
      const doc = await TransactionModel.create({
        userId: txn.userId,
        orderId: txn.orderId,
        symbol: txn.symbol,
        stockName: txn.stockName,
        side: txn.side,
        product: txn.product,
        quantity: txn.quantity,
        price: txn.price,
        totalAmount: txn.totalAmount,
        realizedPnL: txn.realizedPnL,
        timestamp: new Date(txn.timestamp),
      });
      return { ...txn, id: doc._id.toString() };
    }

    const txns = memoryStore.transactions.get(txn.userId) || [];
    txns.unshift(txn);
    memoryStore.transactions.set(txn.userId, txns);
    return txn;
  },

  async getWatchlists(userId: string): Promise<WatchlistGroup[]> {
    if (StorageEngine.isMongoActive()) {
      const docs = await WatchlistModel.find({ userId }).sort({ tabIndex: 1 });
      if (docs.length === 0) {
        // Return default 5 tabs
        return [
          { id: 1, name: 'Watchlist 1', symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY'] },
          { id: 2, name: 'Watchlist 2', symbols: ['ICICIBANK', 'SBIN', 'TATAMOTORS'] },
          { id: 3, name: 'Watchlist 3', symbols: ['ITC', 'LT', 'BAJFINANCE', 'TITAN'] },
          { id: 4, name: 'Watchlist 4', symbols: [] },
          { id: 5, name: 'Watchlist 5', symbols: [] },
        ];
      }
      return docs.map((d) => ({
        id: d.tabIndex,
        name: d.name,
        symbols: d.symbols,
      }));
    }

    const groups = memoryStore.watchlists.get(userId);
    if (!groups || groups.length === 0) {
      const defaultGroups: WatchlistGroup[] = [
        { id: 1, name: 'Watchlist 1', symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY'] },
        { id: 2, name: 'Watchlist 2', symbols: ['ICICIBANK', 'SBIN', 'TATAMOTORS'] },
        { id: 3, name: 'Watchlist 3', symbols: ['ITC', 'LT', 'BAJFINANCE', 'TITAN'] },
        { id: 4, name: 'Watchlist 4', symbols: [] },
        { id: 5, name: 'Watchlist 5', symbols: [] },
      ];
      memoryStore.watchlists.set(userId, defaultGroups);
      return defaultGroups;
    }
    return groups;
  },

  async updateWatchlist(userId: string, tabIndex: number, symbols: string[], name?: string): Promise<WatchlistGroup[]> {
    if (StorageEngine.isMongoActive()) {
      await WatchlistModel.findOneAndUpdate(
        { userId, tabIndex },
        { symbols, ...(name ? { name } : {}) },
        { upsert: true, new: true }
      );
      return StorageEngine.getWatchlists(userId);
    }

    const list = await StorageEngine.getWatchlists(userId);
    const target = list.find((w) => w.id === tabIndex);
    if (target) {
      target.symbols = symbols;
      if (name) target.name = name;
    } else {
      list.push({ id: tabIndex, name: name || `Watchlist ${tabIndex}`, symbols });
    }
    memoryStore.watchlists.set(userId, list);
    return list;
  },
};
