import { INITIAL_STOCKS } from '../../src/services/stockData.ts';
import { Stock, Order, Holding, Transaction, ProductType, OrderSide } from '../../src/types/index.ts';
import { calculateWeightedAverage, calculateRealizedPnL, calculateMarginRequired, validateOrder } from '../../src/utils/calculations.ts';
import { StorageEngine } from './storageEngine.ts';

// In-memory live stock state with micro-fluctuations
let activeStocks: Stock[] = JSON.parse(JSON.stringify(INITIAL_STOCKS));

// Start realistic tick simulation (every 3 seconds)
let tickInterval: NodeJS.Timeout | null = null;

export function startPriceSimulation() {
  if (tickInterval) return;
  tickInterval = setInterval(() => {
    activeStocks = activeStocks.map((stock) => {
      // 40% chance of price tick per stock per interval to keep realism
      if (Math.random() > 0.4) return stock;

      const deltaPercent = (Math.random() - 0.495) * 0.003; // ~0.15% max swing
      const priceChange = Number((stock.currentPrice * deltaPercent).toFixed(2));
      const newPrice = Math.max(1, Number((stock.currentPrice + priceChange).toFixed(2)));
      const change = Number((newPrice - stock.prevClose).toFixed(2));
      const changePercent = Number(((change / stock.prevClose) * 100).toFixed(2));
      const highPrice = Math.max(stock.highPrice, newPrice);
      const lowPrice = Math.min(stock.lowPrice, newPrice);

      // Micro update depth
      const bids = stock.depth.bids.map((b) => ({
        ...b,
        price: Number((b.price + priceChange * 0.5).toFixed(2)),
        quantity: Math.max(100, b.quantity + Math.floor((Math.random() - 0.5) * 200)),
      }));
      const asks = stock.depth.asks.map((a) => ({
        ...a,
        price: Number((a.price + priceChange * 0.5).toFixed(2)),
        quantity: Math.max(100, a.quantity + Math.floor((Math.random() - 0.5) * 200)),
      }));

      return {
        ...stock,
        currentPrice: newPrice,
        change,
        changePercent,
        highPrice,
        lowPrice,
        volume: stock.volume + Math.floor(Math.random() * 50),
        depth: {
          ...stock.depth,
          bids,
          asks,
        },
      };
    });

    // Check limit orders trigger
    evaluatePendingLimitOrders();
  }, 3500);
}

export function getActiveStocks(): Stock[] {
  return activeStocks;
}

export function getStockBySymbol(symbol: string): Stock | null {
  const normalized = symbol.toUpperCase().trim();
  return activeStocks.find((s) => s.symbol === normalized) || null;
}

export async function executeSimulatedTrade(
  userId: string,
  params: {
    symbol: string;
    side: OrderSide;
    product: ProductType;
    type: 'MARKET' | 'LIMIT';
    quantity: number;
    price?: number;
    triggerPrice?: number;
  }
): Promise<{ success: boolean; order?: Order; error?: string }> {
  const stock = getStockBySymbol(params.symbol);
  if (!stock) {
    return { success: false, error: `Stock symbol ${params.symbol} not found.` };
  }

  const user = await StorageEngine.getUserById(userId);
  if (!user) {
    return { success: false, error: 'User account not found.' };
  }

  const holding = await StorageEngine.getHolding(userId, stock.symbol);
  const currentHoldingQty = holding ? holding.quantity : 0;
  const executionPrice = params.type === 'MARKET' ? stock.currentPrice : (params.price || stock.currentPrice);

  // Validate order
  const validation = validateOrder(
    params.side,
    params.quantity,
    executionPrice,
    params.product,
    user.virtualCash,
    currentHoldingQty
  );

  if (!validation.valid) {
    return { success: false, error: validation.error };
  }

  const orderId = 'TX-ORD-' + Math.floor(100000 + Math.random() * 900000);
  const nowIso = new Date().toISOString();

  // If LIMIT order and price not yet crossed, queue as PENDING
  if (params.type === 'LIMIT') {
    const isInstantTrigger =
      (params.side === 'BUY' && stock.currentPrice <= (params.price || 0)) ||
      (params.side === 'SELL' && stock.currentPrice >= (params.price || 0));

    if (!isInstantTrigger) {
      const pendingOrder: Order = {
        id: 'ord_' + Date.now(),
        orderId,
        userId,
        symbol: stock.symbol,
        stockName: stock.name,
        side: params.side,
        product: params.product,
        type: 'LIMIT',
        quantity: params.quantity,
        price: params.price || stock.currentPrice,
        triggerPrice: params.triggerPrice,
        status: 'PENDING',
        statusMessage: `Limit order placed at ₹${params.price}. Waiting for market price match.`,
        createdAt: nowIso,
      };

      const saved = await StorageEngine.createOrder(pendingOrder);
      return { success: true, order: saved };
    }
  }

  // Execute Market or immediately triggered Limit order
  const orderValue = Number((executionPrice * params.quantity).toFixed(2));

  if (params.side === 'BUY') {
    const marginRequired = calculateMarginRequired(executionPrice, params.quantity, params.product);
    
    // Deduct cash
    await StorageEngine.updateUserCash(userId, -marginRequired, params.product === 'MIS' ? marginRequired : 0);

    // Update Holdings for CNC
    if (params.product === 'CNC') {
      const existingHolding = await StorageEngine.getHolding(userId, stock.symbol);
      const newQty = (existingHolding ? existingHolding.quantity : 0) + params.quantity;
      const newAvg = existingHolding
        ? calculateWeightedAverage(existingHolding.quantity, existingHolding.averagePrice, params.quantity, executionPrice)
        : executionPrice;
      const newInvested = Number((newQty * newAvg).toFixed(2));

      await StorageEngine.saveHolding({
        id: existingHolding?.id || 'hld_' + Date.now(),
        userId,
        symbol: stock.symbol,
        stockName: stock.name,
        quantity: newQty,
        averagePrice: newAvg,
        investedValue: newInvested,
        currentPrice: stock.currentPrice,
        currentValue: Number((newQty * stock.currentPrice).toFixed(2)),
        unrealizedPnL: Number((newQty * (stock.currentPrice - newAvg)).toFixed(2)),
        unrealizedPnLPercent: newInvested > 0 ? Number((((newQty * stock.currentPrice - newInvested) / newInvested) * 100).toFixed(2)) : 0,
        dayPnL: Number((newQty * stock.change).toFixed(2)),
        dayPnLPercent: stock.changePercent,
        updatedAt: nowIso,
      });
    }

    // Record order & transaction
    const completedOrder: Order = {
      id: 'ord_' + Date.now(),
      orderId,
      userId,
      symbol: stock.symbol,
      stockName: stock.name,
      side: 'BUY',
      product: params.product,
      type: params.type,
      quantity: params.quantity,
      price: executionPrice,
      executedPrice: executionPrice,
      status: 'COMPLETED',
      statusMessage: `Order executed at ₹${executionPrice.toFixed(2)}`,
      createdAt: nowIso,
      executedAt: nowIso,
    };
    await StorageEngine.createOrder(completedOrder);

    const transaction: Transaction = {
      id: 'txn_' + Date.now(),
      userId,
      orderId,
      symbol: stock.symbol,
      stockName: stock.name,
      side: 'BUY',
      product: params.product,
      quantity: params.quantity,
      price: executionPrice,
      totalAmount: orderValue,
      timestamp: nowIso,
    };
    await StorageEngine.createTransaction(transaction);

    return { success: true, order: completedOrder };
  } else {
    // SELL Order
    const existingHolding = await StorageEngine.getHolding(userId, stock.symbol);
    const avgBuyPrice = existingHolding ? existingHolding.averagePrice : executionPrice;
    const realizedPnL = calculateRealizedPnL(executionPrice, avgBuyPrice, params.quantity);

    // Credit cash
    await StorageEngine.updateUserCash(userId, orderValue, 0);

    // Update or remove holding
    if (existingHolding) {
      const remainingQty = existingHolding.quantity - params.quantity;
      if (remainingQty <= 0) {
        await StorageEngine.deleteHolding(userId, stock.symbol);
      } else {
        const remainingInvested = Number((remainingQty * existingHolding.averagePrice).toFixed(2));
        await StorageEngine.saveHolding({
          ...existingHolding,
          quantity: remainingQty,
          investedValue: remainingInvested,
          currentValue: Number((remainingQty * stock.currentPrice).toFixed(2)),
          unrealizedPnL: Number((remainingQty * (stock.currentPrice - existingHolding.averagePrice)).toFixed(2)),
          updatedAt: nowIso,
        });
      }
    }

    // Record order & transaction
    const completedOrder: Order = {
      id: 'ord_' + Date.now(),
      orderId,
      userId,
      symbol: stock.symbol,
      stockName: stock.name,
      side: 'SELL',
      product: params.product,
      type: params.type,
      quantity: params.quantity,
      price: executionPrice,
      executedPrice: executionPrice,
      status: 'COMPLETED',
      statusMessage: `Order executed at ₹${executionPrice.toFixed(2)}. Realized P&L: ₹${realizedPnL.toFixed(2)}`,
      createdAt: nowIso,
      executedAt: nowIso,
    };
    await StorageEngine.createOrder(completedOrder);

    const transaction: Transaction = {
      id: 'txn_' + Date.now(),
      userId,
      orderId,
      symbol: stock.symbol,
      stockName: stock.name,
      side: 'SELL',
      product: params.product,
      quantity: params.quantity,
      price: executionPrice,
      totalAmount: orderValue,
      realizedPnL,
      timestamp: nowIso,
    };
    await StorageEngine.createTransaction(transaction);

    return { success: true, order: completedOrder };
  }
}

async function evaluatePendingLimitOrders() {
  // Evaluates pending orders against current market prices
  try {
    const demoUser = await StorageEngine.getUserByEmail('demo@tradex.com');
    if (!demoUser) return;

    const orders = await StorageEngine.getOrders(demoUser.id);
    const pendingOrders = orders.filter((o) => o.status === 'PENDING');

    for (const order of pendingOrders) {
      const stock = getStockBySymbol(order.symbol);
      if (!stock) continue;

      let triggered = false;
      if (order.side === 'BUY' && stock.currentPrice <= order.price) {
        triggered = true;
      } else if (order.side === 'SELL' && stock.currentPrice >= order.price) {
        triggered = true;
      }

      if (triggered) {
        const executionPrice = stock.currentPrice;
        await StorageEngine.updateOrder(order.orderId, {
          status: 'COMPLETED',
          executedPrice: executionPrice,
          statusMessage: `Limit triggered and filled at ₹${executionPrice.toFixed(2)}`,
          executedAt: new Date().toISOString(),
        });

        // Update holdings and funds accordingly
        const orderValue = executionPrice * order.quantity;
        if (order.side === 'BUY') {
          await StorageEngine.updateUserCash(order.userId, -orderValue);
          const existing = await StorageEngine.getHolding(order.userId, order.symbol);
          const newQty = (existing?.quantity || 0) + order.quantity;
          const newAvg = existing
            ? calculateWeightedAverage(existing.quantity, existing.averagePrice, order.quantity, executionPrice)
            : executionPrice;
          await StorageEngine.saveHolding({
            id: existing?.id || 'hld_' + Date.now(),
            userId: order.userId,
            symbol: stock.symbol,
            stockName: stock.name,
            quantity: newQty,
            averagePrice: newAvg,
            investedValue: Number((newQty * newAvg).toFixed(2)),
            currentPrice: stock.currentPrice,
            currentValue: Number((newQty * stock.currentPrice).toFixed(2)),
            unrealizedPnL: Number((newQty * (stock.currentPrice - newAvg)).toFixed(2)),
            unrealizedPnLPercent: 0,
            dayPnL: 0,
            dayPnLPercent: 0,
            updatedAt: new Date().toISOString(),
          });
        } else {
          await StorageEngine.updateUserCash(order.userId, orderValue);
          const existing = await StorageEngine.getHolding(order.userId, order.symbol);
          if (existing) {
            const rem = existing.quantity - order.quantity;
            if (rem <= 0) {
              await StorageEngine.deleteHolding(order.userId, order.symbol);
            } else {
              await StorageEngine.saveHolding({
                ...existing,
                quantity: rem,
                investedValue: Number((rem * existing.averagePrice).toFixed(2)),
                currentValue: Number((rem * stock.currentPrice).toFixed(2)),
                unrealizedPnL: Number((rem * (stock.currentPrice - existing.averagePrice)).toFixed(2)),
                updatedAt: new Date().toISOString(),
              });
            }
          }
        }
      }
    }
  } catch (err) {
    // Ignore async tick errors
  }
}

// Start ticker immediately
startPriceSimulation();
