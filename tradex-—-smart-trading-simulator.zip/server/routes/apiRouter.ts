import { Router } from 'express';
import { AuthController } from '../controllers/authController.ts';
import { StockController } from '../controllers/stockController.ts';
import { OrderController } from '../controllers/orderController.ts';
import { HoldingController } from '../controllers/holdingController.ts';
import { FundsController } from '../controllers/fundsController.ts';
import { DashboardController } from '../controllers/dashboardController.ts';
import { WatchlistController } from '../controllers/watchlistController.ts';
import { authMiddleware } from '../middleware/authMiddleware.ts';
import { StorageEngine } from '../services/storageEngine.ts';

const router = Router();

// Health & System status
router.get('/health', (req, res) => {
  res.json({
    status: 'online',
    app: 'TradeX — Smart Trading Simulator',
    time: new Date().toISOString(),
    storage: StorageEngine.getStorageStatus(),
  });
});

// Authentication routes
router.post('/auth/register', AuthController.register);
router.post('/auth/login', AuthController.login);
router.post('/auth/demo-login', AuthController.demoLogin);
router.get('/auth/me', authMiddleware, AuthController.me);

// Stock market data routes (public or authenticated)
router.get('/stocks', StockController.listStocks);
router.get('/stocks/:symbol', StockController.getStock);
router.get('/stocks/:symbol/depth', StockController.getDepth);
router.get('/stocks/:symbol/historical', StockController.getHistorical);

// Orders routes (protected)
router.get('/orders', authMiddleware, OrderController.getOrders);
router.post('/orders', authMiddleware, OrderController.placeOrder);
router.post('/orders/:orderId/cancel', authMiddleware, OrderController.cancelOrder);
router.post('/orders/:orderId/simulate-fill', authMiddleware, OrderController.simulateExecution);

// Holdings & Positions routes (protected)
router.get('/holdings', authMiddleware, HoldingController.getHoldings);
router.get('/positions', authMiddleware, HoldingController.getPositions);
router.post('/positions/square-off', authMiddleware, HoldingController.squareOff);

// Funds & Ledger routes (protected)
router.get('/funds', authMiddleware, FundsController.getFunds);
router.post('/funds/add', authMiddleware, FundsController.addFunds);
router.post('/funds/reset', authMiddleware, FundsController.resetFunds);
router.get('/funds/transactions', authMiddleware, FundsController.getTransactions);

// Dashboard routes (protected)
router.get('/dashboard', authMiddleware, DashboardController.getSummary);

// Watchlist routes (protected)
router.get('/watchlist', authMiddleware, WatchlistController.getWatchlists);
router.post('/watchlist', authMiddleware, WatchlistController.addStock);
router.delete('/watchlist/:tabIndex/:symbol', authMiddleware, WatchlistController.removeStock);

export default router;
