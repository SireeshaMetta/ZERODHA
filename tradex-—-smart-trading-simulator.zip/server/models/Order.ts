import mongoose, { Schema, Document } from 'mongoose';

export interface IOrderDocument extends Document {
  orderId: string;
  userId: string;
  symbol: string;
  stockName: string;
  side: 'BUY' | 'SELL';
  product: 'CNC' | 'MIS';
  type: 'MARKET' | 'LIMIT';
  quantity: number;
  price: number;
  triggerPrice?: number;
  executedPrice?: number;
  status: 'PENDING' | 'COMPLETED' | 'CANCELLED' | 'REJECTED';
  statusMessage?: string;
  createdAt: Date;
  executedAt?: Date;
}

const OrderSchema = new Schema<IOrderDocument>({
  orderId: { type: String, required: true, unique: true },
  userId: { type: String, required: true, index: true },
  symbol: { type: String, required: true },
  stockName: { type: String, required: true },
  side: { type: String, enum: ['BUY', 'SELL'], required: true },
  product: { type: String, enum: ['CNC', 'MIS'], required: true, default: 'CNC' },
  type: { type: String, enum: ['MARKET', 'LIMIT'], required: true, default: 'MARKET' },
  quantity: { type: Number, required: true, min: 1 },
  price: { type: Number, required: true, min: 0 },
  triggerPrice: { type: Number },
  executedPrice: { type: Number },
  status: {
    type: String,
    enum: ['PENDING', 'COMPLETED', 'CANCELLED', 'REJECTED'],
    required: true,
    default: 'PENDING',
  },
  statusMessage: { type: String },
  createdAt: { type: Date, default: Date.now },
  executedAt: { type: Date },
});

export const OrderModel = mongoose.models.Order || mongoose.model<IOrderDocument>('Order', OrderSchema);
