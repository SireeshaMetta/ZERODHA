import mongoose, { Schema, Document } from 'mongoose';

export interface IWatchlistDocument extends Document {
  userId: string;
  tabIndex: number;
  name: string;
  symbols: string[];
}

const WatchlistSchema = new Schema<IWatchlistDocument>({
  userId: { type: String, required: true, index: true },
  tabIndex: { type: Number, required: true, min: 1, max: 7 },
  name: { type: String, required: true, default: 'Watchlist 1' },
  symbols: [{ type: String }],
});

WatchlistSchema.index({ userId: 1, tabIndex: 1 }, { unique: true });

export const WatchlistModel = mongoose.models.Watchlist || mongoose.model<IWatchlistDocument>('Watchlist', WatchlistSchema);
