import mongoose, { Schema, Document } from 'mongoose';

export interface IHoldingDocument extends Document {
  userId: string;
  symbol: string;
  stockName: string;
  quantity: number;
  averagePrice: number;
  investedValue: number;
  updatedAt: Date;
}

const HoldingSchema = new Schema<IHoldingDocument>({
  userId: { type: String, required: true, index: true },
  symbol: { type: String, required: true },
  stockName: { type: String, required: true },
  quantity: { type: Number, required: true, min: 0 },
  averagePrice: { type: Number, required: true, min: 0 },
  investedValue: { type: Number, required: true, min: 0 },
  updatedAt: { type: Date, default: Date.now },
});

HoldingSchema.index({ userId: 1, symbol: 1 }, { unique: true });

export const HoldingModel = mongoose.models.Holding || mongoose.model<IHoldingDocument>('Holding', HoldingSchema);
