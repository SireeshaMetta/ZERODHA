import mongoose, { Schema, Document } from 'mongoose';

export interface ITransactionDocument extends Document {
  userId: string;
  orderId: string;
  symbol: string;
  stockName: string;
  side: 'BUY' | 'SELL';
  product: 'CNC' | 'MIS';
  quantity: number;
  price: number;
  totalAmount: number;
  realizedPnL?: number;
  timestamp: Date;
}

const TransactionSchema = new Schema<ITransactionDocument>({
  userId: { type: String, required: true, index: true },
  orderId: { type: String, required: true },
  symbol: { type: String, required: true },
  stockName: { type: String, required: true },
  side: { type: String, enum: ['BUY', 'SELL'], required: true },
  product: { type: String, enum: ['CNC', 'MIS'], required: true },
  quantity: { type: Number, required: true, min: 1 },
  price: { type: Number, required: true, min: 0 },
  totalAmount: { type: Number, required: true, min: 0 },
  realizedPnL: { type: Number },
  timestamp: { type: Date, default: Date.now },
});

export const TransactionModel = mongoose.models.Transaction || mongoose.model<ITransactionDocument>('Transaction', TransactionSchema);
