import mongoose, { Schema, Document } from 'mongoose';

export interface IUserDocument extends Document {
  name: string;
  email: string;
  passwordHash: string;
  clientCode: string;
  virtualCash: number;
  initialCash: number;
  usedMargin: number;
  createdAt: Date;
}

const UserSchema = new Schema<IUserDocument>({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  clientCode: { type: String, required: true, unique: true },
  virtualCash: { type: Number, required: true, default: 1000000 },
  initialCash: { type: Number, required: true, default: 1000000 },
  usedMargin: { type: Number, required: true, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

export const UserModel = mongoose.models.User || mongoose.model<IUserDocument>('User', UserSchema);
