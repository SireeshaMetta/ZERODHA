import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { StorageEngine } from '../services/storageEngine.ts';
import { getStockBySymbol } from '../services/orderMatchingEngine.ts';

export const WatchlistController = {
  async getWatchlists(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const groups = await StorageEngine.getWatchlists(req.user.userId);
      res.json({ watchlists: groups });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch watchlists' });
    }
  },

  async addStock(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const { tabIndex = 1, symbol } = req.body;
      if (!symbol) {
        res.status(400).json({ error: 'Stock symbol required' });
        return;
      }

      const stock = getStockBySymbol(symbol);
      if (!stock) {
        res.status(404).json({ error: `Stock ${symbol} not found` });
        return;
      }

      const groups = await StorageEngine.getWatchlists(req.user.userId);
      const target = groups.find((g) => g.id === Number(tabIndex)) || groups[0];
      const normalizedSym = stock.symbol;

      if (!target.symbols.includes(normalizedSym)) {
        target.symbols.push(normalizedSym);
        await StorageEngine.updateWatchlist(req.user.userId, target.id, target.symbols, target.name);
      }

      res.json({
        message: `${normalizedSym} added to ${target.name}`,
        watchlists: groups,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to add stock to watchlist' });
    }
  },

  async removeStock(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const { tabIndex = 1, symbol } = req.params;
      const groups = await StorageEngine.getWatchlists(req.user.userId);
      const target = groups.find((g) => g.id === Number(tabIndex));

      if (target) {
        target.symbols = target.symbols.filter((s) => s.toUpperCase() !== symbol.toUpperCase());
        await StorageEngine.updateWatchlist(req.user.userId, target.id, target.symbols, target.name);
      }

      res.json({
        message: `${symbol.toUpperCase()} removed from watchlist`,
        watchlists: groups,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to remove stock from watchlist' });
    }
  },
};
