import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { StorageEngine } from '../services/storageEngine.ts';
import { executeSimulatedTrade, getStockBySymbol } from '../services/orderMatchingEngine.ts';
import { calculateWeightedAverage } from '../../src/utils/calculations.ts';

export const OrderController = {
  async placeOrder(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const { symbol, side, product = 'CNC', type = 'MARKET', quantity, price, triggerPrice } = req.body;

      if (!symbol || !side || !quantity) {
        res.status(400).json({ error: 'Symbol, side, and quantity are required' });
        return;
      }

      const numQty = parseInt(quantity, 10);
      const numPrice = price ? parseFloat(price) : undefined;
      const numTrigger = triggerPrice ? parseFloat(triggerPrice) : undefined;

      const result = await executeSimulatedTrade(req.user.userId, {
        symbol: symbol.toUpperCase(),
        side,
        product,
        type,
        quantity: numQty,
        price: numPrice,
        triggerPrice: numTrigger,
      });

      if (!result.success) {
        res.status(400).json({ error: result.error || 'Failed to place order' });
        return;
      }

      // Return refreshed user funds
      const user = await StorageEngine.getUserById(req.user.userId);

      res.status(201).json({
        message: result.order?.status === 'COMPLETED' ? 'Order executed successfully' : 'Limit order placed in queue',
        order: result.order,
        availableCash: user?.virtualCash,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error processing order' });
    }
  },

  async getOrders(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const { status } = req.query;
      let orders = await StorageEngine.getOrders(req.user.userId);

      if (status && typeof status === 'string' && status !== 'ALL') {
        orders = orders.filter((o) => o.status === status.toUpperCase());
      }

      res.json({
        total: orders.length,
        orders,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch orders' });
    }
  },

  async cancelOrder(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const { orderId } = req.params;
      const order = await StorageEngine.getOrderById(orderId);

      if (!order) {
        res.status(404).json({ error: 'Order not found' });
        return;
      }

      if (order.userId !== req.user.userId) {
        res.status(403).json({ error: 'Forbidden' });
        return;
      }

      if (order.status !== 'PENDING') {
        res.status(400).json({ error: `Cannot cancel order with status: ${order.status}` });
        return;
      }

      const updated = await StorageEngine.updateOrder(order.orderId, {
        status: 'CANCELLED',
        statusMessage: 'Cancelled by user',
      });

      res.json({
        message: 'Order cancelled successfully',
        order: updated,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to cancel order' });
    }
  },

  async simulateExecution(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const { orderId } = req.params;
      const order = await StorageEngine.getOrderById(orderId);

      if (!order) {
        res.status(404).json({ error: 'Order not found' });
        return;
      }

      if (order.status !== 'PENDING') {
        res.status(400).json({ error: `Order is already ${order.status}` });
        return;
      }

      const stock = getStockBySymbol(order.symbol);
      const executionPrice = order.price || (stock ? stock.currentPrice : 100);
      const orderValue = executionPrice * order.quantity;

      if (order.side === 'BUY') {
        await StorageEngine.updateUserCash(order.userId, -orderValue);
        const existing = await StorageEngine.getHolding(order.userId, order.symbol);
        const newQty = (existing?.quantity || 0) + order.quantity;
        const newAvg = existing
          ? calculateWeightedAverage(existing.quantity, existing.averagePrice, order.quantity, executionPrice)
          : executionPrice;

        await StorageEngine.saveHolding({
          id: existing?.id || 'hld_' + Date.now(),
          userId: order.userId,
          symbol: order.symbol,
          stockName: order.stockName,
          quantity: newQty,
          averagePrice: newAvg,
          investedValue: Number((newQty * newAvg).toFixed(2)),
          currentPrice: executionPrice,
          currentValue: Number((newQty * executionPrice).toFixed(2)),
          unrealizedPnL: Number((newQty * (executionPrice - newAvg)).toFixed(2)),
          unrealizedPnLPercent: 0,
          dayPnL: 0,
          dayPnLPercent: 0,
          updatedAt: new Date().toISOString(),
        });
      } else {
        await StorageEngine.updateUserCash(order.userId, orderValue);
        const existing = await StorageEngine.getHolding(order.userId, order.symbol);
        if (existing) {
          const rem = existing.quantity - order.quantity;
          if (rem <= 0) {
            await StorageEngine.deleteHolding(order.userId, order.symbol);
          } else {
            await StorageEngine.saveHolding({
              ...existing,
              quantity: rem,
              investedValue: Number((rem * existing.averagePrice).toFixed(2)),
              currentValue: Number((rem * executionPrice).toFixed(2)),
              unrealizedPnL: Number((rem * (executionPrice - existing.averagePrice)).toFixed(2)),
              updatedAt: new Date().toISOString(),
            });
          }
        }
      }

      const updated = await StorageEngine.updateOrder(order.orderId, {
        status: 'COMPLETED',
        executedPrice: executionPrice,
        statusMessage: `Limit triggered and filled at ₹${executionPrice.toFixed(2)} (Demo Simulated Fill)`,
        executedAt: new Date().toISOString(),
      });

      res.json({
        message: 'Order triggered and executed successfully',
        order: updated,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Execution failed' });
    }
  },
};
