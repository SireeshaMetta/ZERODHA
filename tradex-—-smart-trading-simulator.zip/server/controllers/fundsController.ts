import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { StorageEngine } from '../services/storageEngine.ts';
import { getStockBySymbol } from '../services/orderMatchingEngine.ts';

export const FundsController = {
  async getFunds(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const user = await StorageEngine.getUserById(req.user.userId);
      if (!user) {
        res.status(404).json({ error: 'User not found' });
        return;
      }

      const rawHoldings = await StorageEngine.getHoldings(req.user.userId);
      let holdingsMarketValue = 0;
      for (const h of rawHoldings) {
        const stock = getStockBySymbol(h.symbol);
        const price = stock ? stock.currentPrice : h.averagePrice;
        holdingsMarketValue += h.quantity * price;
      }

      const totalEquity = Number((user.virtualCash + holdingsMarketValue).toFixed(2));

      res.json({
        availableCash: user.virtualCash,
        usedMargin: user.usedMargin,
        initialCash: user.initialCash,
        holdingsMarketValue: Number(holdingsMarketValue.toFixed(2)),
        totalEquity,
        collateralLiquid: 0,
        payin: 0,
        span: 0,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch funds' });
    }
  },

  async addFunds(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const { amount } = req.body;
      const numAmount = parseFloat(amount);
      if (isNaN(numAmount) || numAmount <= 0) {
        res.status(400).json({ error: 'Valid positive amount is required' });
        return;
      }

      const updated = await StorageEngine.updateUserCash(req.user.userId, numAmount);

      res.json({
        message: `Successfully credited virtual cash ₹${numAmount.toLocaleString('en-IN')}`,
        availableCash: updated?.virtualCash,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to add funds' });
    }
  },

  async resetFunds(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const updated = await StorageEngine.resetUserFunds(req.user.userId);

      res.json({
        message: 'Account reset successfully to default state (₹10,00,000 cash).',
        availableCash: updated?.virtualCash,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to reset funds' });
    }
  },

  async getTransactions(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const transactions = await StorageEngine.getTransactions(req.user.userId);
      res.json({
        total: transactions.length,
        transactions,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch transactions' });
    }
  },
};
