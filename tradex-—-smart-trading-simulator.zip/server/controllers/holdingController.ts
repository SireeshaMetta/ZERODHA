import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { StorageEngine } from '../services/storageEngine.ts';
import { getStockBySymbol } from '../services/orderMatchingEngine.ts';
import { Holding } from '../../src/types/index.ts';

export const HoldingController = {
  async getHoldings(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const rawHoldings = await StorageEngine.getHoldings(req.user.userId);

      let totalInvested = 0;
      let totalCurrentValue = 0;
      let totalDayPnL = 0;

      const enrichedHoldings: Holding[] = rawHoldings.map((h) => {
        const stock = getStockBySymbol(h.symbol);
        const currentPrice = stock ? stock.currentPrice : h.averagePrice;
        const change = stock ? stock.change : 0;
        const changePercent = stock ? stock.changePercent : 0;

        const currentValue = Number((h.quantity * currentPrice).toFixed(2));
        const unrealizedPnL = Number((currentValue - h.investedValue).toFixed(2));
        const unrealizedPnLPercent = h.investedValue > 0
          ? Number(((unrealizedPnL / h.investedValue) * 100).toFixed(2))
          : 0;
        const dayPnL = Number((h.quantity * change).toFixed(2));
        const dayPnLPercent = changePercent;

        totalInvested += h.investedValue;
        totalCurrentValue += currentValue;
        totalDayPnL += dayPnL;

        return {
          ...h,
          currentPrice,
          currentValue,
          unrealizedPnL,
          unrealizedPnLPercent,
          dayPnL,
          dayPnLPercent,
        };
      });

      const totalPnL = Number((totalCurrentValue - totalInvested).toFixed(2));
      const totalPnLPercent = totalInvested > 0
        ? Number(((totalPnL / totalInvested) * 100).toFixed(2))
        : 0;

      res.json({
        holdings: enrichedHoldings,
        summary: {
          totalInvested: Number(totalInvested.toFixed(2)),
          totalCurrentValue: Number(totalCurrentValue.toFixed(2)),
          totalPnL,
          totalPnLPercent,
          totalDayPnL: Number(totalDayPnL.toFixed(2)),
          totalCount: enrichedHoldings.length,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch holdings' });
    }
  },

  async getPositions(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      // Check MIS orders from today
      const orders = await StorageEngine.getOrders(req.user.userId);
      const misOrders = orders.filter((o) => o.product === 'MIS' && o.status === 'COMPLETED');

      // Aggregate positions by symbol
      const positionsMap = new Map<string, any>();

      for (const order of misOrders) {
        const stock = getStockBySymbol(order.symbol);
        const currentPrice = stock ? stock.currentPrice : order.price;

        if (!positionsMap.has(order.symbol)) {
          const qty = order.side === 'BUY' ? order.quantity : -order.quantity;
          const pnl = order.side === 'BUY'
            ? (currentPrice - order.price) * order.quantity
            : (order.price - currentPrice) * order.quantity;

          positionsMap.set(order.symbol, {
            id: 'pos_' + order.symbol,
            userId: req.user.userId,
            symbol: order.symbol,
            stockName: order.stockName,
            product: 'MIS',
            quantity: Math.abs(qty),
            buyPrice: order.price,
            currentPrice,
            pnl: Number(pnl.toFixed(2)),
            pnlPercent: Number(((pnl / (order.price * order.quantity)) * 100).toFixed(2)),
            side: order.side,
            status: qty === 0 ? 'CLOSED' : 'OPEN',
          });
        }
      }

      const positions = Array.from(positionsMap.values());
      res.json({ positions });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch positions' });
    }
  },

  async squareOff(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }
      const { symbol } = req.body;
      if (!symbol) {
        res.status(400).json({ error: 'Symbol is required' });
        return;
      }

      res.json({ message: `Intraday position for ${symbol} successfully squared off.` });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Square-off failed' });
    }
  },
};
