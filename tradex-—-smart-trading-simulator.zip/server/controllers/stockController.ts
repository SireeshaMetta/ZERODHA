import { Request, Response } from 'express';
import { getActiveStocks, getStockBySymbol } from '../services/orderMatchingEngine.ts';

export const StockController = {
  listStocks(req: Request, res: Response) {
    try {
      const { search, sector, sortBy } = req.query;
      let stocks = getActiveStocks();

      if (search && typeof search === 'string') {
        const query = search.toLowerCase().trim();
        stocks = stocks.filter(
          (s) => s.symbol.toLowerCase().includes(query) || s.name.toLowerCase().includes(query)
        );
      }

      if (sector && typeof sector === 'string' && sector !== 'ALL') {
        stocks = stocks.filter((s) => s.sector.toLowerCase().includes(sector.toLowerCase()));
      }

      if (sortBy === 'gainers') {
        stocks = [...stocks].sort((a, b) => b.changePercent - a.changePercent);
      } else if (sortBy === 'losers') {
        stocks = [...stocks].sort((a, b) => a.changePercent - b.changePercent);
      } else if (sortBy === 'volume') {
        stocks = [...stocks].sort((a, b) => b.volume - a.volume);
      } else if (sortBy === 'price') {
        stocks = [...stocks].sort((a, b) => b.currentPrice - a.currentPrice);
      }

      res.json({
        total: stocks.length,
        stocks,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to list stocks' });
    }
  },

  getStock(req: Request, res: Response) {
    try {
      const { symbol } = req.params;
      const stock = getStockBySymbol(symbol);
      if (!stock) {
        res.status(404).json({ error: `Stock ${symbol} not found` });
        return;
      }
      res.json({ stock });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to retrieve stock' });
    }
  },

  getDepth(req: Request, res: Response) {
    try {
      const { symbol } = req.params;
      const stock = getStockBySymbol(symbol);
      if (!stock) {
        res.status(404).json({ error: `Stock ${symbol} not found` });
        return;
      }
      res.json({ symbol: stock.symbol, depth: stock.depth });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to retrieve market depth' });
    }
  },

  getHistorical(req: Request, res: Response) {
    try {
      const { symbol } = req.params;
      const timeframe = (req.query.timeframe as '1D' | '1W' | '1M' | '3M' | '1Y') || '1D';
      const stock = getStockBySymbol(symbol);
      if (!stock) {
        res.status(404).json({ error: `Stock ${symbol} not found` });
        return;
      }

      const points = stock.historicalData[timeframe] || stock.historicalData['1D'];
      res.json({
        symbol: stock.symbol,
        timeframe,
        data: points,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to retrieve historical data' });
    }
  },
};
