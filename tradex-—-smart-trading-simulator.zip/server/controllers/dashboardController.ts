import { Response } from 'express';
import { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { StorageEngine } from '../services/storageEngine.ts';
import { getActiveStocks } from '../services/orderMatchingEngine.ts';

export const DashboardController = {
  async getSummary(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }

      const user = await StorageEngine.getUserById(req.user.userId);
      if (!user) {
        res.status(404).json({ error: 'User not found' });
        return;
      }

      const allStocks = getActiveStocks();
      const rawHoldings = await StorageEngine.getHoldings(req.user.userId);
      const orders = await StorageEngine.getOrders(req.user.userId);

      let totalInvestment = 0;
      let holdingsMarketValue = 0;
      let todayPnL = 0;

      for (const h of rawHoldings) {
        const stock = allStocks.find((s) => s.symbol === h.symbol);
        const currentPrice = stock ? stock.currentPrice : h.averagePrice;
        const change = stock ? stock.change : 0;

        totalInvestment += h.investedValue;
        holdingsMarketValue += h.quantity * currentPrice;
        todayPnL += h.quantity * change;
      }

      const portfolioValue = Number((user.virtualCash + holdingsMarketValue).toFixed(2));
      const overallPnL = Number((holdingsMarketValue - totalInvestment).toFixed(2));
      const overallPnLPercent = totalInvestment > 0
        ? Number(((overallPnL / totalInvestment) * 100).toFixed(2))
        : 0;
      const todayPnLPercent = holdingsMarketValue > 0
        ? Number(((todayPnL / holdingsMarketValue) * 100).toFixed(2))
        : 0;

      // Sorted gainers and losers
      const sortedByGain = [...allStocks].sort((a, b) => b.changePercent - a.changePercent);
      const topGainers = sortedByGain.slice(0, 4);
      const topLosers = [...sortedByGain].reverse().slice(0, 4);

      // Recent 5 orders
      const recentOrders = orders.slice(0, 5);

      const storageInfo = StorageEngine.getStorageStatus();

      res.json({
        portfolioValue,
        totalInvestment: Number(totalInvestment.toFixed(2)),
        holdingsMarketValue: Number(holdingsMarketValue.toFixed(2)),
        overallPnL,
        overallPnLPercent,
        todayPnL: Number(todayPnL.toFixed(2)),
        todayPnLPercent,
        availableCash: user.virtualCash,
        usedMargin: user.usedMargin,
        holdingsCount: rawHoldings.length,
        recentOrders,
        topGainers,
        topLosers,
        storageInfo,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to generate dashboard summary' });
    }
  },
};
