import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { StorageEngine } from '../services/storageEngine.ts';
import { AuthenticatedRequest } from '../middleware/authMiddleware.ts';

const JWT_SECRET = process.env.JWT_SECRET || 'tradex_jwt_secret_developer_key_2026';

export const AuthController = {
  async register(req: Request, res: Response) {
    try {
      const { name, email, password } = req.body;
      if (!name || !email || !password) {
        res.status(400).json({ error: 'Name, email, and password are required' });
        return;
      }

      if (password.length < 6) {
        res.status(400).json({ error: 'Password must be at least 6 characters long' });
        return;
      }

      const existing = await StorageEngine.getUserByEmail(email);
      if (existing) {
        res.status(409).json({ error: 'An account with this email already exists' });
        return;
      }

      const salt = await bcrypt.genSalt(10);
      const passwordHash = await bcrypt.hash(password, salt);

      const user = await StorageEngine.createUser({
        name,
        email,
        passwordHash,
      });

      const token = jwt.sign(
        { userId: user.id, email: user.email, clientCode: user.clientCode },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.status(201).json({
        message: 'Registration successful',
        token,
        user,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Registration failed' });
    }
  },

  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        res.status(400).json({ error: 'Email and password are required' });
        return;
      }

      const userWithHash = await StorageEngine.getUserByEmail(email);
      if (!userWithHash) {
        res.status(401).json({ error: 'Invalid email or password' });
        return;
      }

      const isMatch = await bcrypt.compare(password, userWithHash.passwordHash);
      if (!isMatch) {
        res.status(401).json({ error: 'Invalid email or password' });
        return;
      }

      const token = jwt.sign(
        { userId: userWithHash.id, email: userWithHash.email, clientCode: userWithHash.clientCode },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      const { passwordHash: _, ...user } = userWithHash;

      res.json({
        message: 'Login successful',
        token,
        user,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Login failed' });
    }
  },

  async demoLogin(req: Request, res: Response) {
    try {
      const demoUser = await StorageEngine.getUserByEmail('demo@tradex.com');
      if (!demoUser) {
        res.status(404).json({ error: 'Demo user account not found' });
        return;
      }

      const token = jwt.sign(
        { userId: demoUser.id, email: demoUser.email, clientCode: demoUser.clientCode },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      const { passwordHash: _, ...user } = demoUser;

      res.json({
        message: 'Demo login successful',
        token,
        user,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Demo login failed' });
    }
  },

  async me(req: AuthenticatedRequest, res: Response) {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Unauthorized' });
        return;
      }
      const user = await StorageEngine.getUserById(req.user.userId);
      if (!user) {
        res.status(404).json({ error: 'User not found' });
        return;
      }
      res.json({ user });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch user profile' });
    }
  },
};
