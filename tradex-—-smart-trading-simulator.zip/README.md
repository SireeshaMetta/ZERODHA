# TradeX — Smart Trading Simulator
### Zerodha Kite Inspired Full-Stack Paper Trading Platform

**TradeX** is a complete, professional, full-stack paper-trading and portfolio simulator built for software engineering demonstrations. Inspired by the minimalist layout, signature pinned watchlist, and lightning-fast order execution of **Zerodha Kite**, TradeX provides an educational risk-free environment for trading simulated Indian equities.

---

## Key Features

1. **Zerodha Kite Trading Terminal Layout**:
   - Pinned 5-tab market watchlist with quick hover action buttons (`[B]` Buy, `[S]` Sell, Chart, and Depth).
   - Signature floating **Buy (Blue) / Sell (Orange/Red)** order window with real-time margin requirement calculations.
   - Dual product selection: Intraday Margin (`MIS` with 5x leverage) vs Long-term Cash & Carry (`CNC` with 100% cash).
   - Order types: **Market** (instant execution) and **Limit** (pending trigger matching against simulated ticks).

2. **Accurate Financial Calculations Engine**:
   - **Weighted-Average Purchase Cost**: Recalculates exact volume-weighted cost basis upon acquiring additional lots:
     $$\text{AvgCost} = \frac{(\text{Qty}_{\text{existing}} \times \text{Avg}_{\text{existing}}) + (\text{Qty}_{\text{new}} \times \text{Price}_{\text{new}})}{\text{Qty}_{\text{existing}} + \text{Qty}_{\text{new}}}$$
   - **Realized P&L**: Computed accurately upon partial or complete share liquidation and permanently locked into the ledger.
   - **Unrealized P&L & Day P&L**: Dynamically calculated against live micro-fluctuations.
   - **Margin Verification**: Rejects orders with insufficient virtual cash or invalid holdings.

3. **Interactive Stock Analytics**:
   - Timeframe price charts (`1D`, `1W`, `1M`, `3M`, `1Y`) powered by Recharts.
   - Simulated volume histograms.
   - Level 2 Market Depth (Top 5 Bids and Asks with buy/sell balance percentage).
   - 17+ Indian bluechips including `RELIANCE`, `TCS`, `HDFCBANK`, `INFY`, `ICICIBANK`, `SBIN`, `TATAMOTORS`, `BHARTIARTL`, `ITC`, and `TITAN`.

4. **Full-Stack Architecture & Data Persistence**:
   - **Backend**: Node.js & Express.js REST APIs with centralized error handling.
   - **Authentication**: JWT token authentication with bcrypt password hashing.
   - **Hybrid Storage Engine**: Seamlessly connects to real MongoDB via Mongoose when `MONGODB_URI` is provided; automatically falls back to a high-performance local store when MongoDB is not running, ensuring zero downtime.
   - **Audit Trail & CSV Export**: Complete trade history ledger downloadable with one click.

---

## Technology Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS 4, Recharts, Lucide React, React Router 7, Axios
- **Backend**: Node.js, Express.js, TypeScript (`tsx`), Mongoose, JSON Web Tokens (`jsonwebtoken`), `bcryptjs`
- **Testing**: Dedicated unit test suite with 100% calculation pass rate (`src/tests/tradingEngine.test.ts`)

---

## Installation & Setup Instructions

### Prerequisites
- Node.js (version 18+ or 20+ recommended)
- npm or yarn

### Windows PowerShell

```powershell
# 1. Clone repository and navigate to project root
cd TradeX

# 2. Install dependencies
npm install

# 3. Configure environment variables (optional)
# By default, TradeX runs with its built-in hybrid storage engine out of the box.
# If connecting to an external MongoDB instance:
Copy-Item .env.example .env
# Open .env and adjust MONGODB_URI if desired

# 4. Start Full-Stack Development Server (Express + Vite)
npm run dev

# 5. Open your browser
# Navigate to: http://localhost:3000
```

### macOS / Linux

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

---

## Testing & Verification

TradeX includes an executable unit test suite covering:
- Weighted-average purchase price calculations.
- Realized profit and loss calculation on partial and full exits.
- Unrealized return calculations and Day P&L.
- Margin calculations for CNC vs MIS products.
- Order validation checks for insufficient funds and insufficient holdings.
- Standard Indian currency formatting (`₹1,23,456.78`).

To run and verify tests:
- Click the **"Verify Tests (100% Pass)"** badge in the bottom-left corner of the running web application to view live assertion results.
- Run `npm run lint` to verify TypeScript typing and syntax.

---

## API Endpoints Reference

### Authentication
- `POST /api/auth/register` — Create new trader account (includes initial ₹10,00,000 virtual cash)
- `POST /api/auth/login` — Sign in with email and password
- `POST /api/auth/demo-login` — Instant access with pre-configured demo account (`TX9082`)
- `GET /api/auth/me` — Retrieve current authenticated user profile

### Equities & Market Feeds
- `GET /api/stocks` — List all equities with query filters (`search`, `sector`, `sortBy`)
- `GET /api/stocks/:symbol` — Detailed view for a specific stock
- `GET /api/stocks/:symbol/depth` — Level 2 Market Depth (top 5 bids and asks)
- `GET /api/stocks/:symbol/historical` — Candlestick historical series (`1D`, `1W`, `1M`, `3M`, `1Y`)

### Orders & Execution
- `GET /api/orders` — List orders with status filters (`ALL`, `PENDING`, `COMPLETED`, `CANCELLED`)
- `POST /api/orders` — Place Buy/Sell order (Market or Limit, CNC or MIS)
- `POST /api/orders/:orderId/cancel` — Cancel pending limit order
- `POST /api/orders/:orderId/simulate-fill` — Force instant execution of pending limit order (for demos)

### Portfolio & Holdings
- `GET /api/holdings` — List user's delivery holdings with real-time mark-to-market P&L
- `GET /api/positions` — List intraday MIS positions
- `POST /api/positions/square-off` — Square off intraday position

### Funds & Ledger
- `GET /api/funds` — Retrieve available cash, used margin, and account equity
- `POST /api/funds/add` — Deposit virtual simulated funds
- `POST /api/funds/reset` — Reset portfolio to initial ₹10,00,000 state
- `GET /api/funds/transactions` — Retrieve trade history and realized P&L ledger

### Diagnostics
- `GET /api/health` — System status, storage mode, and memory health

---

## Educational Disclaimer
*TradeX is an educational paper-trading simulator built for software engineering portfolios. All prices, order fills, and fund balances are strictly simulated. TradeX does not connect to a real brokerage or execute real financial trades.*
