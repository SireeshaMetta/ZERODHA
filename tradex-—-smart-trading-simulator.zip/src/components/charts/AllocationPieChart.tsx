import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Holding } from '../../types/index.ts';
import { formatINR } from '../../utils/calculations.ts';

interface AllocationPieChartProps {
  holdings: Holding[];
}

const COLORS = ['#2563eb', '#16a34a', '#d97706', '#9333ea', '#0891b2', '#e11d48', '#4b5563'];

export const AllocationPieChart: React.FC<AllocationPieChartProps> = ({ holdings }) => {
  if (holdings.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 text-center text-xs text-slate-400">
        No active holdings to display allocation.
      </div>
    );
  }

  const data = holdings.map((h) => ({
    name: h.symbol,
    value: h.currentValue,
  }));

  const totalValue = data.reduce((acc, curr) => acc + curr.value, 0);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const item = payload[0];
      const pct = totalValue > 0 ? ((item.value / totalValue) * 100).toFixed(1) : '0';
      return (
        <div className="bg-slate-900 text-white p-2 rounded-lg border border-slate-700 text-xs shadow-lg">
          <div className="font-semibold">{item.name}</div>
          <div className="font-mono text-slate-300">{formatINR(item.value)} ({pct}%)</div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
        <h4 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider">
          Portfolio Allocation
        </h4>
        <span className="font-mono text-xs text-slate-500">Total: {formatINR(totalValue)}</span>
      </div>

      <div className="h-48 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              innerRadius={45}
              outerRadius={75}
              paddingAngle={3}
              dataKey="value"
            >
              {data.map((_, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center justify-center gap-3 pt-2 text-xs">
        {data.map((item, index) => {
          const pct = totalValue > 0 ? ((item.value / totalValue) * 100).toFixed(1) : '0';
          return (
            <div key={item.name} className="flex items-center gap-1.5">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: COLORS[index % COLORS.length] }}
              />
              <span className="font-medium text-slate-700 dark:text-slate-300">{item.name}</span>
              <span className="font-mono text-[11px] text-slate-400">({pct}%)</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
