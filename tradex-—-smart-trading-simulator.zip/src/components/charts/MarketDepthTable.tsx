import React from 'react';
import { StockMarketDepth } from '../../types/index.ts';

interface MarketDepthTableProps {
  depth: StockMarketDepth;
  openPrice: number;
  highPrice: number;
  lowPrice: number;
  prevClose: number;
  week52High: number;
  week52Low: number;
}

export const MarketDepthTable: React.FC<MarketDepthTableProps> = ({
  depth,
  openPrice,
  highPrice,
  lowPrice,
  prevClose,
  week52High,
  week52Low,
}) => {
  const maxBidQty = Math.max(...depth.bids.map((b) => b.quantity), 1);
  const maxAskQty = Math.max(...depth.asks.map((a) => a.quantity), 1);

  const total = depth.totalBids + depth.totalAsks;
  const bidRatio = total > 0 ? (depth.totalBids / total) * 100 : 50;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
        <h4 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider">
          Market Depth (Level 2)
        </h4>
        <span className="text-[11px] text-slate-400">Top 5 Bids & Asks</span>
      </div>

      {/* 2-Column Split: Bids (Blue/Green) vs Asks (Red) */}
      <div className="grid grid-cols-2 gap-4 text-xs">
        {/* Bids Column */}
        <div>
          <div className="grid grid-cols-3 text-[11px] font-semibold text-slate-400 pb-1.5 border-b border-slate-100 dark:border-slate-800">
            <span>Bid Price</span>
            <span className="text-center">Orders</span>
            <span className="text-right">Qty</span>
          </div>
          <div className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono tabular-nums">
            {depth.bids.map((bid, i) => {
              const widthPct = Math.min(100, (bid.quantity / maxBidQty) * 100);
              return (
                <div key={i} className="relative py-1.5 grid grid-cols-3 items-center">
                  {/* Subtle depth bar background */}
                  <div
                    className="absolute inset-y-0 right-0 bg-blue-100/60 dark:bg-blue-950/40 pointer-events-none rounded-xs"
                    style={{ width: `${widthPct}%` }}
                  />
                  <span className="font-semibold text-blue-600 dark:text-blue-400 z-10">
                    ₹{bid.price.toFixed(2)}
                  </span>
                  <span className="text-center text-slate-500 z-10">{bid.orders}</span>
                  <span className="text-right text-slate-700 dark:text-slate-300 z-10">
                    {bid.quantity.toLocaleString('en-IN')}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between font-mono font-semibold text-slate-800 dark:text-slate-200">
            <span>Total Bids:</span>
            <span>{depth.totalBids.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Asks Column */}
        <div>
          <div className="grid grid-cols-3 text-[11px] font-semibold text-slate-400 pb-1.5 border-b border-slate-100 dark:border-slate-800">
            <span>Ask Price</span>
            <span className="text-center">Orders</span>
            <span className="text-right">Qty</span>
          </div>
          <div className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono tabular-nums">
            {depth.asks.map((ask, i) => {
              const widthPct = Math.min(100, (ask.quantity / maxAskQty) * 100);
              return (
                <div key={i} className="relative py-1.5 grid grid-cols-3 items-center">
                  <div
                    className="absolute inset-y-0 left-0 bg-rose-100/60 dark:bg-rose-950/40 pointer-events-none rounded-xs"
                    style={{ width: `${widthPct}%` }}
                  />
                  <span className="font-semibold text-rose-600 dark:text-rose-400 z-10">
                    ₹{ask.price.toFixed(2)}
                  </span>
                  <span className="text-center text-slate-500 z-10">{ask.orders}</span>
                  <span className="text-right text-slate-700 dark:text-slate-300 z-10">
                    {ask.quantity.toLocaleString('en-IN')}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between font-mono font-semibold text-slate-800 dark:text-slate-200">
            <span>Total Asks:</span>
            <span>{depth.totalAsks.toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>

      {/* Bid / Ask Ratio Visualizer */}
      <div className="space-y-1">
        <div className="flex justify-between text-[11px] font-mono text-slate-500">
          <span>Buyers: {bidRatio.toFixed(1)}%</span>
          <span>Sellers: {(100 - bidRatio).toFixed(1)}%</span>
        </div>
        <div className="h-1.5 w-full bg-rose-500 rounded-full overflow-hidden flex">
          <div className="bg-blue-600 h-full transition-all" style={{ width: `${bidRatio}%` }} />
        </div>
      </div>

      {/* Fundamental Stat Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px]">
        <div>
          <span className="text-slate-400 block">Open</span>
          <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
            ₹{openPrice.toFixed(2)}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block">High</span>
          <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
            ₹{highPrice.toFixed(2)}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block">Low</span>
          <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
            ₹{lowPrice.toFixed(2)}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block">Prev Close</span>
          <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
            ₹{prevClose.toFixed(2)}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block">52W High</span>
          <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
            ₹{week52High.toFixed(2)}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block">52W Low</span>
          <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
            ₹{week52Low.toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
};
