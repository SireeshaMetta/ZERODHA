import React, { useState } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import { Stock, HistoricalPoint } from '../../types/index.ts';
import { formatINR } from '../../utils/calculations.ts';

interface StockPriceChartProps {
  stock: Stock;
}

export const StockPriceChart: React.FC<StockPriceChartProps> = ({ stock }) => {
  const [timeframe, setTimeframe] = useState<'1D' | '1W' | '1M' | '3M' | '1Y'>('1D');
  const [chartMode, setChartMode] = useState<'area' | 'candles'>('area');

  const dataPoints: HistoricalPoint[] = stock.historicalData[timeframe] || stock.historicalData['1D'];
  const isPositive = stock.change >= 0;
  const strokeColor = isPositive ? '#16a34a' : '#dc2626';
  const fillColor = isPositive ? '#16a34a' : '#dc2626';

  // Find min and max for responsive Y domain padding
  const prices = dataPoints.map((p) => p.price);
  const minPrice = Math.floor(Math.min(...prices) * 0.995);
  const maxPrice = Math.ceil(Math.max(...prices) * 1.005);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload as HistoricalPoint;
      return (
        <div className="bg-slate-900 text-white p-2.5 rounded-lg border border-slate-700 shadow-xl text-xs space-y-1">
          <div className="font-semibold text-slate-300">{data.time}</div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-slate-400">Price:</span>
            <span className="font-mono font-bold">{formatINR(data.price)}</span>
          </div>
          <div className="flex items-center justify-between gap-4 text-[11px] text-slate-400">
            <span>High: ₹{data.high}</span>
            <span>Low: ₹{data.low}</span>
          </div>
          <div className="flex items-center justify-between gap-4 text-[11px] text-slate-400">
            <span>Volume:</span>
            <span className="font-mono">{data.volume.toLocaleString('en-IN')}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
      {/* Header Controls: Timeframes & Mode */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
          {(['1D', '1W', '1M', '3M', '1Y'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                timeframe === tf
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Range Low:</span>
            <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
              ₹{minPrice}
            </span>
          </div>
          <span className="text-slate-300 dark:text-slate-700">·</span>
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Range High:</span>
            <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
              ₹{maxPrice}
            </span>
          </div>
        </div>
      </div>

      {/* Primary Price Chart */}
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={dataPoints} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={fillColor} stopOpacity={0.25} />
                <stop offset="95%" stopColor={fillColor} stopOpacity={0.0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="time"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: '#94a3b8' }}
              minTickGap={25}
            />
            <YAxis
              domain={[minPrice, maxPrice]}
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: '#94a3b8' }}
              tickFormatter={(val) => `₹${val}`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="price"
              stroke={strokeColor}
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#priceGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Sub-Chart: Simulated Volume Bars */}
      <div>
        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
          <span>Trading Volume</span>
          <span className="font-mono text-slate-500">
            Total Today: {stock.volume.toLocaleString('en-IN')} shares
          </span>
        </div>
        <div className="h-16 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={dataPoints} margin={{ top: 0, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="time" hide />
              <YAxis hide />
              <Bar dataKey="volume" fill="#94a3b8" opacity={0.4} radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
