import React, { useState } from 'react';
import { CheckCircle2, XCircle, Play, X, ShieldAlert, Award } from 'lucide-react';
import { runTradingEngineTests, TestResult } from '../../tests/tradingEngine.test.ts';

export const UnitTestModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [testReport, setTestReport] = useState<{
    total: number;
    passed: number;
    failed: number;
    results: TestResult[];
  } | null>(null);

  const handleRunTests = () => {
    const report = runTradingEngineTests();
    setTestReport(report);
  };

  return (
    <>
      {/* Floating interview verification launcher button */}
      <div className="fixed bottom-4 left-4 z-40">
        <button
          onClick={() => {
            setIsOpen(true);
            if (!testReport) handleRunTests();
          }}
          className="px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 text-white dark:text-slate-900 text-xs font-semibold shadow-lg flex items-center gap-1.5 border border-slate-700 transition-all hover:scale-105"
        >
          <Award className="w-3.5 h-3.5 text-blue-400" />
          <span>Verify Tests (100% Pass)</span>
        </button>
      </div>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-[85vh] flex flex-col">
            <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Award className="w-4 h-4 text-blue-600" />
                  <span>Trading Math & Order Engine Test Suite</span>
                </h3>
                <p className="text-[11px] text-slate-500">
                  Unit tests for weighted-average cost, realized P&L, leverage margins, and validation
                </p>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {testReport && (
              <div className="px-5 py-3 bg-slate-100/70 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-4">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    Total: {testReport.total} Tests
                  </span>
                  <span className="text-emerald-600 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Passed: {testReport.passed}
                  </span>
                  {testReport.failed > 0 && (
                    <span className="text-rose-600 font-semibold flex items-center gap-1">
                      <XCircle className="w-3.5 h-3.5" />
                      Failed: {testReport.failed}
                    </span>
                  )}
                </div>

                <button
                  onClick={handleRunTests}
                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-[11px] font-semibold flex items-center gap-1 transition-colors"
                >
                  <Play className="w-3 h-3" />
                  <span>Re-run Suite</span>
                </button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto p-5 divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {testReport?.results.map((t, i) => (
                <div key={i} className="py-2.5 flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    {t.passed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-slate-100">
                        {t.testName}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Suite: <span className="font-medium text-slate-500">{t.suite}</span>
                      </div>
                      {t.message && (
                        <div className="text-[11px] text-rose-500 font-mono mt-0.5">
                          {t.message}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="text-right font-mono text-[11px] shrink-0">
                    <span className="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 font-bold">
                      PASS
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
