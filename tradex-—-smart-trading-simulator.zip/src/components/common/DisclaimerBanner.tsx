import React from 'react';
import { Info, Database } from 'lucide-react';
import { useTrading } from '../../context/TradingContext.tsx';

export const DisclaimerBanner: React.FC = () => {
  const { storageStatus } = useTrading();

  return (
    <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 px-6 py-2 text-xs flex flex-wrap items-center justify-between gap-3 text-slate-600 dark:text-slate-400">
      <div className="flex items-center gap-2">
        <Info className="w-3.5 h-3.5 text-blue-500 shrink-0" />
        <span>
          <strong className="font-semibold text-slate-800 dark:text-slate-200">Simulated Trading Environment:</strong> All stock quotes, order executions, and portfolio balances are simulated for educational demonstration. No real financial capital or brokerage connectivity.
        </span>
      </div>

      <div className="flex items-center gap-2 text-[11px] font-mono shrink-0">
        <Database className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-slate-500">Engine:</span>
        <span className="font-semibold text-slate-700 dark:text-slate-300">
          {storageStatus.mode}
        </span>
      </div>
    </div>
  );
};
