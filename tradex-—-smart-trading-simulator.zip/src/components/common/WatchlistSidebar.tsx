import React, { useState } from 'react';
import { Search, Plus, Trash2, LineChart, BarChart2 } from 'lucide-react';
import { useTrading } from '../../context/TradingContext.tsx';
import { Stock } from '../../types/index.ts';

interface WatchlistSidebarProps {
  onSelectStock?: (stock: Stock) => void;
}

export const WatchlistSidebar: React.FC<WatchlistSidebarProps> = ({ onSelectStock }) => {
  const {
    stocks,
    selectedStock,
    setSelectedStock,
    watchlists,
    activeWatchlistTab,
    setActiveWatchlistTab,
    addStockToWatchlist,
    removeStockFromWatchlist,
    openOrderModal,
  } = useTrading();

  const [searchQuery, setSearchQuery] = useState('');
  const [hoveredSymbol, setHoveredSymbol] = useState<string | null>(null);

  // Active tab stocks
  const currentGroup = watchlists.find((w) => w.id === activeWatchlistTab) || watchlists[0];
  const activeSymbols = currentGroup ? currentGroup.symbols : [];

  // Stocks belonging to this watchlist tab
  const tabStocks = stocks.filter((s) => activeSymbols.includes(s.symbol));

  // Available stocks not yet in this tab for adding
  const availableToAdd = searchQuery.trim()
    ? stocks.filter(
        (s) =>
          !activeSymbols.includes(s.symbol) &&
          (s.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
            s.name.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  const handleStockClick = (stock: Stock) => {
    setSelectedStock(stock);
    if (onSelectStock) {
      onSelectStock(stock);
    }
  };

  return (
    <aside className="w-full lg:w-80 shrink-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col h-[calc(100vh-80px)] lg:sticky lg:top-[80px]">
      {/* Search Header */}
      <div className="p-3 border-b border-slate-200 dark:border-slate-800">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search & add to watchlist (e.g. TCS)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* If Searching, show stocks to add */}
      {searchQuery.trim() && (
        <div className="bg-blue-50/70 dark:bg-blue-950/40 p-2 border-b border-blue-200/50 dark:border-blue-900 text-xs">
          <div className="font-semibold text-slate-700 dark:text-slate-300 px-2 py-1 flex items-center justify-between text-[11px]">
            <span>ADD TO WATCHLIST {activeWatchlistTab}</span>
            <span className="text-slate-400">{availableToAdd.length} found</span>
          </div>
          <div className="max-h-48 overflow-y-auto divide-y divide-blue-100 dark:divide-blue-900/50">
            {availableToAdd.length > 0 ? (
              availableToAdd.map((stock) => (
                <div
                  key={stock.symbol}
                  className="px-2 py-1.5 flex items-center justify-between hover:bg-white dark:hover:bg-slate-800 rounded transition-colors"
                >
                  <div>
                    <div className="font-semibold text-slate-800 dark:text-slate-200">{stock.symbol}</div>
                    <div className="text-[10px] text-slate-500 truncate max-w-[140px]">{stock.name}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      ₹{stock.currentPrice.toFixed(2)}
                    </span>
                    <button
                      onClick={() => {
                        addStockToWatchlist(stock.symbol);
                        setSearchQuery('');
                      }}
                      className="p-1 rounded bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                      title="Add to watchlist"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-3 text-center text-slate-500 text-[11px]">
                No matching available stocks to add
              </div>
            )}
          </div>
        </div>
      )}

      {/* Stock List in Active Tab */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/80">
        {tabStocks.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            <p className="font-medium text-slate-600 dark:text-slate-400">Watchlist {activeWatchlistTab} is empty</p>
            <p className="mt-1 text-[11px]">Type in the search box above to add equities like RELIANCE, TCS, INFY.</p>
          </div>
        ) : (
          tabStocks.map((stock) => {
            const isSelected = selectedStock?.symbol === stock.symbol;
            const isHovered = hoveredSymbol === stock.symbol;
            const isPositive = stock.change >= 0;

            return (
              <div
                key={stock.symbol}
                onMouseEnter={() => setHoveredSymbol(stock.symbol)}
                onMouseLeave={() => setHoveredSymbol(null)}
                onClick={() => handleStockClick(stock)}
                className={`relative px-4 py-2.5 cursor-pointer transition-colors ${
                  isSelected
                    ? 'bg-blue-50/60 dark:bg-blue-950/30 border-l-2 border-blue-600'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center justify-between">
                  {/* Stock Symbol & Exchange */}
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-xs text-slate-900 dark:text-slate-100">
                        {stock.symbol}
                      </span>
                      <span className="text-[9px] uppercase tracking-wider text-slate-400 font-mono">
                        {stock.exchange}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[130px]">
                      {stock.sector}
                    </div>
                  </div>

                  {/* Stock Price & Change or Hover Actions */}
                  {isHovered ? (
                    /* Signature Zerodha Kite Hover Action Buttons */
                    <div
                      className="flex items-center gap-1"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {/* Buy [B] */}
                      <button
                        onClick={() => openOrderModal(stock, 'BUY')}
                        className="w-6 h-6 rounded bg-[#4184f3] hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center shadow-xs transition-colors"
                        title="Buy (B)"
                      >
                        B
                      </button>

                      {/* Sell [S] */}
                      <button
                        onClick={() => openOrderModal(stock, 'SELL')}
                        className="w-6 h-6 rounded bg-[#ff5722] hover:bg-orange-700 text-white font-bold text-xs flex items-center justify-center shadow-xs transition-colors"
                        title="Sell (S)"
                      >
                        S
                      </button>

                      {/* View Chart */}
                      <button
                        onClick={() => handleStockClick(stock)}
                        className="w-6 h-6 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center transition-colors"
                        title="Open Interactive Chart"
                      >
                        <LineChart className="w-3.5 h-3.5" />
                      </button>

                      {/* Delete from Watchlist */}
                      <button
                        onClick={() => removeStockFromWatchlist(stock.symbol)}
                        className="w-6 h-6 rounded bg-slate-100 dark:bg-slate-800 hover:bg-rose-100 dark:hover:bg-rose-950 text-slate-500 hover:text-rose-600 flex items-center justify-center transition-colors"
                        title="Remove from tab"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    /* Default Price Display */
                    <div className="text-right">
                      <div className="font-mono tabular-nums text-xs font-semibold text-slate-900 dark:text-slate-100">
                        ₹{stock.currentPrice.toFixed(2)}
                      </div>
                      <div
                        className={`font-mono tabular-nums text-[11px] font-medium ${
                          isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {isPositive ? '+' : ''}
                        {stock.change.toFixed(2)} ({isPositive ? '+' : ''}
                        {stock.changePercent.toFixed(2)}%)
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Pinned Bottom Tab Selector (Tabs 1, 2, 3, 4, 5 like Zerodha Kite) */}
      <div className="border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 p-1 flex items-center justify-around text-xs">
        {[1, 2, 3, 4, 5].map((tabNum) => {
          const isActive = activeWatchlistTab === tabNum;
          const count = (watchlists.find((w) => w.id === tabNum)?.symbols || []).length;
          return (
            <button
              key={tabNum}
              onClick={() => setActiveWatchlistTab(tabNum)}
              className={`flex-1 py-1.5 text-center text-xs font-semibold rounded transition-colors ${
                isActive
                  ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs border border-slate-200 dark:border-slate-700'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <span>{tabNum}</span>
              {count > 0 && <span className="text-[10px] text-slate-400 ml-1">({count})</span>}
            </button>
          );
        })}
      </div>
    </aside>
  );
};
