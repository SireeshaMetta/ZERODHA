import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  TrendingUp,
  Moon,
  Sun,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Layers,
  FileText,
  PieChart,
  Briefcase,
  Wallet,
  Activity,
  Settings,
  HelpCircle,
  RefreshCw,
  Search,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { useTrading } from '../../context/TradingContext.tsx';
import { useTheme } from '../../context/ThemeContext.tsx';
import { formatINR } from '../../utils/calculations.ts';

export const Navbar: React.FC = () => {
  const { user, logout, demoLogin } = useAuth();
  const { funds, stocks, setSelectedStock, isSimulatingTicks, togglePriceSimulation } = useTrading();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [quickSearch, setQuickSearch] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);

  // Filtered search results
  const searchMatches = quickSearch.trim()
    ? stocks.filter(
        (s) =>
          s.symbol.toLowerCase().includes(quickSearch.toLowerCase()) ||
          s.name.toLowerCase().includes(quickSearch.toLowerCase())
      ).slice(0, 5)
    : [];

  const navLinks = [
    { to: '/', label: 'Dashboard', icon: Activity },
    { to: '/orders', label: 'Orders', icon: FileText },
    { to: '/holdings', label: 'Holdings', icon: Briefcase },
    { to: '/positions', label: 'Positions', icon: Layers },
    { to: '/funds', label: 'Funds', icon: Wallet },
    { to: '/watchlist', label: 'Screener', icon: PieChart },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors">
      {/* Upper Bar: Indices & Quick Tickers */}
      <div className="hidden lg:flex items-center justify-between px-6 py-1.5 text-xs border-b border-slate-100 dark:border-slate-800/60 bg-slate-50/70 dark:bg-slate-900/50">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700 dark:text-slate-300">NIFTY 50</span>
            <span className="font-mono tabular-nums font-medium text-emerald-600 dark:text-emerald-400">
              24,852.15
            </span>
            <span className="font-mono tabular-nums text-slate-500 text-[11px]">+112.40 (+0.45%)</span>
          </div>
          <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">·</span>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700 dark:text-slate-300">SENSEX</span>
            <span className="font-mono tabular-nums font-medium text-emerald-600 dark:text-emerald-400">
              81,420.30
            </span>
            <span className="font-mono tabular-nums text-slate-500 text-[11px]">+340.20 (+0.42%)</span>
          </div>
          <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">·</span>
          <div className="flex items-center gap-2 text-slate-500">
            <span>Market Status:</span>
            <span className="inline-flex items-center text-emerald-600 dark:text-emerald-400 font-medium">
              Open (Simulated)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={togglePriceSimulation}
            className="flex items-center gap-1.5 text-[11px] text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 transition-colors"
            title="Toggle live price ticks"
          >
            <RefreshCw className={`w-3 h-3 ${isSimulatingTicks ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
            <span>Ticks: {isSimulatingTicks ? 'Active' : 'Paused'}</span>
          </button>
          <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">·</span>
          <span className="text-slate-500 text-[11px]">
            Paper Trading Terminal
          </span>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="flex items-center justify-between px-6 py-2.5">
        {/* Left: Brand Identity & Quick Search */}
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2.5 shrink-0 group">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm group-hover:bg-blue-700 transition-colors">
              <TrendingUp className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg tracking-tight text-slate-900 dark:text-white leading-none">
                TradeX
              </span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 font-medium tracking-wide">
                KITE SIMULATOR
              </span>
            </div>
          </Link>

          {/* Global Stock Search */}
          <div className="relative hidden md:block w-64">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search stocks (e.g. INFY, RELIANCE)"
                value={quickSearch}
                onChange={(e) => {
                  setQuickSearch(e.target.value);
                  setShowSearchResults(true);
                }}
                onFocus={() => setShowSearchResults(true)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-lg border border-transparent focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900 focus:outline-none transition-all"
              />
            </div>

            {/* Quick Search Dropdown */}
            {showSearchResults && searchMatches.length > 0 && (
              <div className="absolute left-0 top-full mt-1.5 w-80 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 shadow-xl z-50 overflow-hidden">
                <div className="px-3 py-2 text-[11px] font-semibold text-slate-400 border-b border-slate-100 dark:border-slate-700">
                  MATCHING STOCKS
                </div>
                <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700/60">
                  {searchMatches.map((stock) => (
                    <button
                      key={stock.symbol}
                      onClick={() => {
                        setSelectedStock(stock);
                        setShowSearchResults(false);
                        setQuickSearch('');
                      }}
                      className="w-full px-3 py-2 text-left flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
                    >
                      <div>
                        <div className="font-semibold text-xs text-slate-900 dark:text-slate-100">
                          {stock.symbol}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate max-w-[160px]">
                          {stock.name}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono tabular-nums text-xs font-medium text-slate-900 dark:text-slate-100">
                          ₹{stock.currentPrice.toFixed(2)}
                        </div>
                        <div
                          className={`font-mono tabular-nums text-[11px] ${
                            stock.change >= 0 ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          {stock.change >= 0 ? '+' : ''}
                          {stock.changePercent.toFixed(2)}%
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Center: Clean Text Navigation Links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-600 dark:text-slate-300">
          {navLinks.map((item) => {
            const isActive = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`whitespace-nowrap transition-colors py-1 ${
                  isActive
                    ? 'text-blue-600 dark:text-blue-400 font-semibold border-b-2 border-blue-600 dark:border-blue-400'
                    : 'hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Right: Available Funds, Theme Toggle, Profile Menu */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Virtual Available Cash indicator */}
          <Link
            to="/funds"
            className="hidden sm:flex flex-col items-end px-3 py-1 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-blue-400 transition-colors"
            title="Available Virtual Cash for Orders"
          >
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
              Available Cash
            </span>
            <span className="font-mono tabular-nums text-xs font-bold text-slate-800 dark:text-slate-200">
              {formatINR(funds.availableCash)}
            </span>
          </Link>

          {/* Theme Switcher */}
          <button
            onClick={toggleTheme}
            className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* User Account / Profile Menu */}
          <div className="relative">
            <button
              onClick={() => setShowProfileMenu((prev) => !prev)}
              className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
            >
              <div className="w-7 h-7 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-semibold text-xs flex items-center justify-center overflow-hidden border border-blue-300/60 dark:border-blue-700">
                <img
                  src="/src/assets/images/trader_avatar_1792393502552.jpg"
                  alt="Trader Profile"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Fallback to text initials
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 leading-none">
                  {user ? user.clientCode || 'TX9082' : 'Guest'}
                </span>
                <span className="text-[10px] text-slate-400 dark:text-slate-500">
                  {user ? user.name.split(' ')[0] : 'Demo User'}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
            </button>

            {/* Profile Dropdown */}
            {showProfileMenu && (
              <div
                className="absolute right-0 top-full mt-2 w-64 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-xl py-2 z-50 text-xs"
                onClick={() => setShowProfileMenu(false)}
              >
                <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-700/60">
                  <div className="font-semibold text-sm text-slate-900 dark:text-white">
                    {user?.name || 'Metta Sireesha'}
                  </div>
                  <div className="text-slate-500 text-xs">{user?.email || 'demo@tradex.com'}</div>
                  <div className="mt-2 inline-flex items-center gap-1.5 text-[11px] font-mono text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded">
                    <span>Client Code:</span>
                    <span className="font-bold">{user?.clientCode || 'TX9082'}</span>
                  </div>
                </div>

                <div className="py-1">
                  <Link
                    to="/profile"
                    className="flex items-center gap-2.5 px-4 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50"
                  >
                    <UserIcon className="w-4 h-4 text-slate-400" />
                    <span>Profile & Risk Settings</span>
                  </Link>
                  <Link
                    to="/funds"
                    className="flex items-center gap-2.5 px-4 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50"
                  >
                    <Wallet className="w-4 h-4 text-slate-400" />
                    <span>Manage Virtual Funds</span>
                  </Link>
                  <Link
                    to="/orders"
                    className="flex items-center gap-2.5 px-4 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50"
                  >
                    <FileText className="w-4 h-4 text-slate-400" />
                    <span>Order Book & GTT</span>
                  </Link>
                  <Link
                    to="/history"
                    className="flex items-center gap-2.5 px-4 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50"
                  >
                    <TrendingUp className="w-4 h-4 text-slate-400" />
                    <span>Trade History & Ledger</span>
                  </Link>
                </div>

                <div className="border-t border-slate-100 dark:border-slate-700/60 pt-1 mt-1">
                  <button
                    onClick={() => demoLogin()}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50"
                  >
                    <RefreshCw className="w-4 h-4 text-blue-500" />
                    <span>Switch to Demo Account</span>
                  </button>
                  <button
                    onClick={() => logout()}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  >
                    <LogOut className="w-4 h-4 text-rose-500" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation Strip */}
      <div className="flex lg:hidden overflow-x-auto border-t border-slate-200 dark:border-slate-800 px-4 py-2 gap-4 text-xs font-medium bg-white dark:bg-slate-900">
        {navLinks.map((item) => {
          const isActive = location.pathname === item.to;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={`whitespace-nowrap px-2.5 py-1 rounded-md transition-colors ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-semibold'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {item.label}
            </Link>
          );
        })}
      </div>
    </header>
  );
};
