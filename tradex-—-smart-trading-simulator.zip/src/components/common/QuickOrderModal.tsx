import React, { useState, useEffect } from 'react';
import { X, AlertCircle, CheckCircle, ShieldCheck } from 'lucide-react';
import { useTrading } from '../../context/TradingContext.tsx';
import { ProductType, OrderSide, OrderType } from '../../types/index.ts';
import { formatINR, calculateMarginRequired } from '../../utils/calculations.ts';

export const QuickOrderModal: React.FC = () => {
  const { orderModal, closeOrderModal, executeTrade, funds, holdings } = useTrading();

  if (!orderModal.isOpen || !orderModal.stock) return null;

  const stock = orderModal.stock;
  const [side, setSide] = useState<OrderSide>(orderModal.side);
  const [product, setProduct] = useState<ProductType>(orderModal.product);
  const [orderType, setOrderType] = useState<OrderType>(orderModal.type);
  const [quantity, setQuantity] = useState<number>(orderModal.quantity || 1);
  const [limitPrice, setLimitPrice] = useState<number>(orderModal.limitPrice || stock.currentPrice);
  const [triggerPrice, setTriggerPrice] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync when modal opens or stock changes
  useEffect(() => {
    setSide(orderModal.side);
    setProduct(orderModal.product);
    setOrderType(orderModal.type);
    setQuantity(orderModal.quantity || 1);
    setLimitPrice(orderModal.limitPrice || stock.currentPrice);
    setShowConfirm(false);
    setErrorMessage(null);
  }, [orderModal]);

  // Existing holding for this stock
  const currentHolding = holdings.find((h) => h.symbol === stock.symbol);
  const holdingQuantity = currentHolding ? currentHolding.quantity : 0;

  // Calculation of effective price & margin required
  const effectivePrice = orderType === 'MARKET' ? stock.currentPrice : limitPrice;
  const totalOrderValue = Number((effectivePrice * quantity).toFixed(2));
  const marginRequired = calculateMarginRequired(effectivePrice, quantity, product);
  const isSufficientFunds = side === 'SELL' || marginRequired <= funds.availableCash;
  const isSufficientHoldings = side === 'BUY' || (product === 'CNC' ? quantity <= holdingQuantity : true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (quantity <= 0 || !Number.isInteger(quantity)) {
      setErrorMessage('Please specify a valid whole number quantity.');
      return;
    }

    if (orderType === 'LIMIT' && (!limitPrice || limitPrice <= 0)) {
      setErrorMessage('Please enter a valid limit price.');
      return;
    }

    if (side === 'BUY' && marginRequired > funds.availableCash) {
      setErrorMessage(`Insufficient virtual funds. Required: ${formatINR(marginRequired)}, Available: ${formatINR(funds.availableCash)}`);
      return;
    }

    if (side === 'SELL' && product === 'CNC' && quantity > holdingQuantity) {
      setErrorMessage(`Insufficient holdings. You only own ${holdingQuantity} shares of ${stock.symbol}.`);
      return;
    }

    // Require confirmation step
    if (!showConfirm) {
      setShowConfirm(true);
      return;
    }

    setIsSubmitting(true);
    const result = await executeTrade({
      symbol: stock.symbol,
      side,
      product,
      type: orderType,
      quantity,
      price: effectivePrice,
      triggerPrice: triggerPrice ? parseFloat(triggerPrice) : undefined,
    });

    setIsSubmitting(false);
    if (!result.success) {
      setErrorMessage(result.error || 'Failed to place order.');
      setShowConfirm(false);
    }
  };

  const isBuy = side === 'BUY';
  const headerBg = isBuy ? 'bg-[#4184f3]' : 'bg-[#ff5722]';
  const actionButtonBg = isBuy
    ? 'bg-[#4184f3] hover:bg-blue-700 text-white'
    : 'bg-[#ff5722] hover:bg-orange-700 text-white';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Zerodha Kite Characteristic Top Bar */}
        <div className={`${headerBg} text-white px-5 py-3.5 flex items-center justify-between`}>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm tracking-wide">{side} {stock.symbol}</span>
              <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded font-mono uppercase">
                {stock.exchange}
              </span>
              <span className="text-xs font-mono font-medium">₹{stock.currentPrice.toFixed(2)}</span>
            </div>
            <div className="text-[11px] text-white/80">{stock.name}</div>
          </div>
          <button
            onClick={closeOrderModal}
            className="p-1 rounded-md hover:bg-white/20 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector: BUY vs SELL toggle */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
          <button
            type="button"
            onClick={() => {
              setSide('BUY');
              setShowConfirm(false);
            }}
            className={`flex-1 py-2 text-xs font-semibold text-center transition-colors ${
              side === 'BUY'
                ? 'text-[#4184f3] border-b-2 border-[#4184f3] bg-white dark:bg-slate-900'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            BUY
          </button>
          <button
            type="button"
            onClick={() => {
              setSide('SELL');
              setShowConfirm(false);
            }}
            className={`flex-1 py-2 text-xs font-semibold text-center transition-colors ${
              side === 'SELL'
                ? 'text-[#ff5722] border-b-2 border-[#ff5722] bg-white dark:bg-slate-900'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            SELL
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Error Message */}
          {errorMessage && (
            <div className="flex items-start gap-2 p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-lg text-xs text-rose-700 dark:text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Product Type: MIS (Intraday) vs CNC (Longterm) */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Product Type
            </label>
            <div className="grid grid-cols-2 gap-3">
              <label
                className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                  product === 'MIS'
                    ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/30'
                    : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <input
                  type="radio"
                  name="product"
                  checked={product === 'MIS'}
                  onChange={() => setProduct('MIS')}
                  className="text-blue-600 focus:ring-0"
                />
                <div>
                  <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                    Intraday (MIS)
                  </div>
                  <div className="text-[10px] text-slate-400">5x leverage margin</div>
                </div>
              </label>

              <label
                className={`flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                  product === 'CNC'
                    ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/30'
                    : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <input
                  type="radio"
                  name="product"
                  checked={product === 'CNC'}
                  onChange={() => setProduct('CNC')}
                  className="text-blue-600 focus:ring-0"
                />
                <div>
                  <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                    Longterm (CNC)
                  </div>
                  <div className="text-[10px] text-slate-400">100% Cash / Delivery</div>
                </div>
              </label>
            </div>
          </div>

          {/* Order Type: Market vs Limit */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Order Type
            </label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="orderType"
                  checked={orderType === 'MARKET'}
                  onChange={() => setOrderType('MARKET')}
                  className="text-blue-600 focus:ring-0"
                />
                <span>Market (Instant Fill)</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="orderType"
                  checked={orderType === 'LIMIT'}
                  onChange={() => setOrderType('LIMIT')}
                  className="text-blue-600 focus:ring-0"
                />
                <span>Limit (Price Trigger)</span>
              </label>
            </div>
          </div>

          {/* Quantity & Price Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Qty (Shares)
              </label>
              <input
                type="number"
                min="1"
                step="1"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
              />
              {side === 'SELL' && (
                <div className="text-[10px] text-slate-400 mt-1">
                  Holding: <span className="font-mono font-semibold">{holdingQuantity}</span> shares
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Price (₹)
              </label>
              <input
                type="number"
                min="0.05"
                step="0.05"
                disabled={orderType === 'MARKET'}
                value={orderType === 'MARKET' ? stock.currentPrice : limitPrice}
                onChange={(e) => setLimitPrice(parseFloat(e.target.value) || 0)}
                className={`w-full px-3 py-2 text-sm font-mono tabular-nums rounded-lg border ${
                  orderType === 'MARKET'
                    ? 'bg-slate-100 dark:bg-slate-800/50 text-slate-400 border-slate-200 dark:border-slate-700 cursor-not-allowed'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700 focus:outline-none focus:border-blue-500'
                }`}
              />
              <div className="text-[10px] text-slate-400 mt-1">
                Tick size: 0.05
              </div>
            </div>
          </div>

          {/* Real-time Order Summary strip */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
            <div className="flex items-center justify-between text-slate-500">
              <span>Order Value:</span>
              <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                {formatINR(totalOrderValue)}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-500">
              <span>Margin Required:</span>
              <span className="font-mono tabular-nums font-semibold text-blue-600 dark:text-blue-400">
                {formatINR(marginRequired)}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-500">
              <span>Available Cash:</span>
              <span
                className={`font-mono tabular-nums font-semibold ${
                  isSufficientFunds ? 'text-slate-700 dark:text-slate-300' : 'text-rose-600'
                }`}
              >
                {formatINR(funds.availableCash)}
              </span>
            </div>
          </div>

          {/* Confirmation Notice if prompted */}
          {showConfirm && (
            <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-lg text-xs flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-blue-900 dark:text-blue-200">Confirm Simulated Order:</span>
                <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                  Are you sure you want to {side} {quantity} shares of {stock.symbol} at {orderType === 'MARKET' ? 'Market Price' : `₹${limitPrice}`} ({product})?
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={closeOrderModal}
              className="flex-1 py-2.5 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || (!isSufficientFunds && side === 'BUY') || (!isSufficientHoldings && side === 'SELL')}
              className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${actionButtonBg} ${
                isSubmitting || (!isSufficientFunds && side === 'BUY') || (!isSufficientHoldings && side === 'SELL')
                  ? 'opacity-50 cursor-not-allowed'
                  : ''
              }`}
            >
              {isSubmitting ? (
                <span>Executing...</span>
              ) : showConfirm ? (
                <span>Confirm {side}</span>
              ) : (
                <span>{side} {stock.symbol}</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
