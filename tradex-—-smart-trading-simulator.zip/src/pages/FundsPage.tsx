import React, { useState } from 'react';
import { Wallet, PlusCircle, RotateCcw, ShieldCheck, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useTrading } from '../context/TradingContext.tsx';
import { formatINR } from '../utils/calculations.ts';

export const FundsPage: React.FC = () => {
  const { funds, addFunds, resetAccount } = useTrading();
  const [depositAmount, setDepositAmount] = useState<string>('100000');
  const [isDepositing, setIsDepositing] = useState<boolean>(false);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount <= 0) return;

    setIsDepositing(true);
    await addFunds(amount);
    setIsDepositing(false);
  };

  const handleReset = async () => {
    setIsResetting(true);
    await resetAccount();
    setIsResetting(false);
    setShowResetConfirm(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5">
        <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Wallet className="w-5 h-5 text-blue-600" />
            <span>Funds & Margin Statement</span>
          </h2>
          <p className="text-xs text-slate-500">
            Paper-trading capital balance, collateral liquid limits, and simulated deposit controls
          </p>
        </div>

        {/* 4-Box Funds Overview (Zerodha Kite Style) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 font-mono tabular-nums">
          <div className="p-4 rounded-lg bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/60 dark:border-blue-900">
            <span className="font-sans text-[11px] font-semibold text-blue-600 dark:text-blue-400 block">
              Available Margin (Cash)
            </span>
            <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              {formatINR(funds.availableCash)}
            </div>
            <span className="font-sans text-[10px] text-slate-400">Ready for instant order placement</span>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="font-sans text-[11px] font-semibold text-slate-500 block">
              Used Margin
            </span>
            <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              {formatINR(funds.usedMargin)}
            </div>
            <span className="font-sans text-[10px] text-slate-400">Committed in active intraday positions</span>
          </div>

          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <span className="font-sans text-[11px] font-semibold text-slate-500 block">
              Holdings Valuation
            </span>
            <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              {formatINR(funds.holdingsMarketValue)}
            </div>
            <span className="font-sans text-[10px] text-slate-400">Current market value of delivery shares</span>
          </div>

          <div className="p-4 rounded-lg bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-900">
            <span className="font-sans text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 block">
              Total Account Equity
            </span>
            <div className="text-xl font-bold text-emerald-700 dark:text-emerald-300 mt-1">
              {formatINR(funds.totalEquity)}
            </div>
            <span className="font-sans text-[10px] text-slate-400">Cash + Live Stock Value</span>
          </div>
        </div>
      </div>

      {/* 2-Column Action Panels: Add Simulated Cash vs Reset Account */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Add Funds Panel */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <PlusCircle className="w-4 h-4 text-emerald-600" />
              <span>Add Virtual Funds</span>
            </h3>
            <p className="text-xs text-slate-500">
              Instantly replenish your paper trading balance to practice large position sizing
            </p>
          </div>

          <form onSubmit={handleDeposit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Deposit Amount (₹)
              </label>
              <input
                type="number"
                min="1000"
                step="5000"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Quick Preset Buttons */}
            <div className="flex flex-wrap gap-2">
              {['50000', '100000', '500000', '1000000'].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setDepositAmount(val)}
                  className={`px-3 py-1 text-xs font-mono rounded-md border transition-colors ${
                    depositAmount === val
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-semibold'
                      : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  +{formatINR(parseInt(val, 10))}
                </button>
              ))}
            </div>

            <button
              type="submit"
              disabled={isDepositing}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isDepositing ? 'Crediting Virtual Funds...' : 'Credit Simulated Funds'}</span>
            </button>
          </form>
        </div>

        {/* Reset Account Panel */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-rose-500" />
              <span>Reset Simulator Portfolio</span>
            </h3>
            <p className="text-xs text-slate-500">
              Clear all simulated test trades and restore your balance back to default ₹10,00,000
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-400 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-slate-800 dark:text-slate-200">
              <ShieldCheck className="w-4 h-4 text-blue-500" />
              <span>Reset Behavior:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-500 text-[11px]">
              <li>Resets cash balance to ₹10,00,000.00 virtual cash</li>
              <li>Clears pending & completed orders</li>
              <li>Wipes simulated open holdings and transaction history</li>
              <li>Restores default benchmark watchlists</li>
            </ul>
          </div>

          {!showResetConfirm ? (
            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="w-full py-2.5 border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 dark:text-rose-400 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset Entire Portfolio</span>
            </button>
          ) : (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 rounded-lg space-y-3">
              <div className="flex items-start gap-2 text-xs text-rose-800 dark:text-rose-200">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>
                  Are you sure you want to restore the default ₹10,00,000 state? This cannot be undone.
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(false)}
                  className="flex-1 py-1.5 text-xs font-semibold rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleReset}
                  disabled={isResetting}
                  className="flex-1 py-1.5 text-xs font-bold rounded bg-rose-600 hover:bg-rose-700 text-white transition-colors"
                >
                  {isResetting ? 'Resetting...' : 'Yes, Reset Now'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
