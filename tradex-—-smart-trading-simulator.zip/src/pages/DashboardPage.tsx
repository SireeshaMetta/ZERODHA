import React from 'react';
import { Link } from 'react-router-dom';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Briefcase,
  Clock,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { useTrading } from '../context/TradingContext.tsx';
import { formatINR, formatPercent } from '../utils/calculations.ts';
import { StockPriceChart } from '../components/charts/StockPriceChart.tsx';
import { AllocationPieChart } from '../components/charts/AllocationPieChart.tsx';

export const DashboardPage: React.FC = () => {
  const {
    funds,
    holdingsSummary,
    holdings,
    orders,
    stocks,
    selectedStock,
    setSelectedStock,
    openOrderModal,
    simulateLimitFill,
  } = useTrading();

  // Top gainers and losers
  const sortedGainers = [...stocks].sort((a, b) => b.changePercent - a.changePercent).slice(0, 4);
  const sortedLosers = [...stocks].sort((a, b) => a.changePercent - b.changePercent).slice(0, 4);

  // Recent 5 orders
  const recentOrders = orders.slice(0, 5);

  const isTotalPnLPositive = holdingsSummary.totalPnL >= 0;
  const isDayPnLPositive = holdingsSummary.totalDayPnL >= 0;

  return (
    <div className="space-y-6">
      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Portfolio Value */}
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
            <span>Portfolio Value</span>
            <Wallet className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {formatINR(funds.totalEquity)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Cash + Live Holdings
          </div>
        </div>

        {/* Available Virtual Cash */}
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
            <span>Available Cash</span>
            <Link to="/funds" className="text-blue-600 hover:underline text-[11px]">
              Add
            </Link>
          </div>
          <div className="mt-2 text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {formatINR(funds.availableCash)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Used Margin: {formatINR(funds.usedMargin)}
          </div>
        </div>

        {/* Total Investment */}
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
            <span>Total Invested</span>
            <Briefcase className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {formatINR(holdingsSummary.totalInvested)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Holdings Count: {holdingsSummary.totalCount}
          </div>
        </div>

        {/* Overall Profit / Loss */}
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
            <span>Total P&L</span>
            {isTotalPnLPositive ? (
              <TrendingUp className="w-4 h-4 text-emerald-500" />
            ) : (
              <TrendingDown className="w-4 h-4 text-rose-500" />
            )}
          </div>
          <div
            className={`mt-2 text-lg font-bold font-mono tabular-nums ${
              isTotalPnLPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {formatINR(holdingsSummary.totalPnL, true)}
          </div>
          <div
            className={`mt-1 text-[11px] font-mono tabular-nums font-semibold ${
              isTotalPnLPositive ? 'text-emerald-600' : 'text-rose-600'
            }`}
          >
            {formatPercent(holdingsSummary.totalPnLPercent)} Return
          </div>
        </div>

        {/* Today's Profit / Loss */}
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
            <span>Today's P&L</span>
            <Clock className="w-4 h-4 text-slate-400" />
          </div>
          <div
            className={`mt-2 text-lg font-bold font-mono tabular-nums ${
              isDayPnLPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {formatINR(holdingsSummary.totalDayPnL, true)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Intraday portfolio shift
          </div>
        </div>
      </div>

      {/* Main Focus: Selected Stock Detailed Chart & Quick Order Bar */}
      {selectedStock && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  {selectedStock.symbol}
                </h3>
                <span className="text-xs px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
                  {selectedStock.exchange}
                </span>
                <span className="text-xs text-slate-400">· {selectedStock.sector}</span>
              </div>
              <div className="text-xs text-slate-500 mt-0.5">{selectedStock.name}</div>
            </div>

            <div className="flex items-center gap-6">
              <div className="text-right">
                <div className="text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                  ₹{selectedStock.currentPrice.toFixed(2)}
                </div>
                <div
                  className={`text-xs font-mono tabular-nums font-semibold ${
                    selectedStock.change >= 0 ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {selectedStock.change >= 0 ? '+' : ''}
                  {selectedStock.change.toFixed(2)} ({selectedStock.change >= 0 ? '+' : ''}
                  {selectedStock.changePercent.toFixed(2)}%)
                </div>
              </div>

              {/* Quick Trade Triggers */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openOrderModal(selectedStock, 'BUY')}
                  className="px-4 py-2 bg-[#4184f3] hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
                >
                  <span>BUY</span>
                  <span className="text-[10px] opacity-75 font-mono">[B]</span>
                </button>
                <button
                  onClick={() => openOrderModal(selectedStock, 'SELL')}
                  className="px-4 py-2 bg-[#ff5722] hover:bg-orange-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
                >
                  <span>SELL</span>
                  <span className="text-[10px] opacity-75 font-mono">[S]</span>
                </button>
              </div>
            </div>
          </div>

          {/* Interactive Chart */}
          <StockPriceChart stock={selectedStock} />
        </div>
      )}

      {/* 2-Column Split: Top Movers vs Allocation & Recent Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Market Movers: Gainers & Losers */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h4 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              Market Movers (Live Simulated)
            </h4>
            <Link to="/watchlist" className="text-xs text-blue-600 hover:underline flex items-center">
              <span>All Equities</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Gainers */}
            <div>
              <div className="text-[11px] font-semibold text-emerald-600 uppercase tracking-wider mb-2 flex items-center gap-1">
                <ArrowUpRight className="w-3.5 h-3.5" />
                <span>Top Gainers</span>
              </div>
              <div className="space-y-2">
                {sortedGainers.map((stock) => (
                  <div
                    key={stock.symbol}
                    onClick={() => setSelectedStock(stock)}
                    className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-xs text-slate-800 dark:text-slate-200">
                        {stock.symbol}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[100px]">
                        {stock.sector}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono tabular-nums text-xs font-semibold text-slate-900 dark:text-slate-100">
                        ₹{stock.currentPrice.toFixed(2)}
                      </div>
                      <div className="font-mono tabular-nums text-[11px] font-medium text-emerald-600">
                        +{stock.changePercent.toFixed(2)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Losers */}
            <div>
              <div className="text-[11px] font-semibold text-rose-600 uppercase tracking-wider mb-2 flex items-center gap-1">
                <ArrowDownRight className="w-3.5 h-3.5" />
                <span>Top Losers</span>
              </div>
              <div className="space-y-2">
                {sortedLosers.map((stock) => (
                  <div
                    key={stock.symbol}
                    onClick={() => setSelectedStock(stock)}
                    className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-xs text-slate-800 dark:text-slate-200">
                        {stock.symbol}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[100px]">
                        {stock.sector}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono tabular-nums text-xs font-semibold text-slate-900 dark:text-slate-100">
                        ₹{stock.currentPrice.toFixed(2)}
                      </div>
                      <div className="font-mono tabular-nums text-[11px] font-medium text-rose-600">
                        {stock.changePercent.toFixed(2)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Portfolio Asset Allocation Donut */}
        <AllocationPieChart holdings={holdings} />
      </div>

      {/* Recent Simulated Orders Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <h4 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              Recent Simulated Orders
            </h4>
            <p className="text-[11px] text-slate-400">Latest executed & pending paper trades</p>
          </div>
          <Link to="/orders" className="text-xs text-blue-600 hover:underline flex items-center">
            <span>View Full Order Book</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {recentOrders.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400">
            No simulated orders placed yet. Click Buy or Sell on any stock to execute your first simulated trade!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-semibold">
                  <th className="pb-2">Time</th>
                  <th className="pb-2">Order ID</th>
                  <th className="pb-2">Symbol</th>
                  <th className="pb-2">Side</th>
                  <th className="pb-2">Type</th>
                  <th className="pb-2 text-right">Qty</th>
                  <th className="pb-2 text-right">Price</th>
                  <th className="pb-2 text-center">Status</th>
                  <th className="pb-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono tabular-nums">
                {recentOrders.map((order) => {
                  const isBuy = order.side === 'BUY';
                  const isPending = order.status === 'PENDING';

                  return (
                    <tr key={order.orderId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 text-slate-500 font-sans text-[11px]">
                        {new Date(order.createdAt).toLocaleTimeString()}
                      </td>
                      <td className="py-2.5 text-slate-500">{order.orderId}</td>
                      <td className="py-2.5 font-bold font-sans text-slate-900 dark:text-slate-100">
                        {order.symbol}
                      </td>
                      <td className="py-2.5">
                        <span
                          className={`font-semibold ${
                            isBuy ? 'text-blue-600' : 'text-orange-600'
                          }`}
                        >
                          {order.side}
                        </span>
                      </td>
                      <td className="py-2.5 text-slate-500">{order.product} · {order.type}</td>
                      <td className="py-2.5 text-right font-semibold text-slate-800 dark:text-slate-200">
                        {order.quantity}
                      </td>
                      <td className="py-2.5 text-right">₹{(order.executedPrice || order.price).toFixed(2)}</td>
                      <td className="py-2.5 text-center">
                        <span
                          className={`font-sans text-[11px] font-semibold ${
                            order.status === 'COMPLETED'
                              ? 'text-emerald-600'
                              : order.status === 'PENDING'
                              ? 'text-amber-600'
                              : 'text-rose-600'
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>
                      <td className="py-2.5 text-right">
                        {isPending && (
                          <button
                            onClick={() => simulateLimitFill(order.orderId)}
                            className="text-[10px] font-sans px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 text-blue-600 hover:bg-blue-100 transition-colors"
                            title="Simulate immediate fill for demonstration"
                          >
                            Fill Now
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
