import React, { useState } from 'react';
import { Search, Filter, TrendingUp, TrendingDown, ArrowUpDown, Plus, Eye, BarChart2 } from 'lucide-react';
import { useTrading } from '../context/TradingContext.tsx';
import { Stock } from '../types/index.ts';
import { formatINR, formatPercent } from '../utils/calculations.ts';
import { StockPriceChart } from '../components/charts/StockPriceChart.tsx';
import { MarketDepthTable } from '../components/charts/MarketDepthTable.tsx';

export const WatchlistPage: React.FC = () => {
  const { stocks, selectedStock, setSelectedStock, openOrderModal, addStockToWatchlist, activeWatchlistTab } = useTrading();
  const [search, setSearch] = useState('');
  const [selectedSector, setSelectedSector] = useState('ALL');
  const [sortBy, setSortBy] = useState<'default' | 'gainers' | 'losers' | 'volume' | 'price'>('default');

  const sectors = ['ALL', ...Array.from(new Set(stocks.map((s) => s.sector)))];

  let filtered = stocks.filter((s) => {
    const matchesSearch =
      s.symbol.toLowerCase().includes(search.toLowerCase()) ||
      s.name.toLowerCase().includes(search.toLowerCase());
    const matchesSector = selectedSector === 'ALL' || s.sector === selectedSector;
    return matchesSearch && matchesSector;
  });

  if (sortBy === 'gainers') {
    filtered = [...filtered].sort((a, b) => b.changePercent - a.changePercent);
  } else if (sortBy === 'losers') {
    filtered = [...filtered].sort((a, b) => a.changePercent - b.changePercent);
  } else if (sortBy === 'volume') {
    filtered = [...filtered].sort((a, b) => b.volume - a.volume);
  } else if (sortBy === 'price') {
    filtered = [...filtered].sort((a, b) => b.currentPrice - a.currentPrice);
  }

  const activeStock = selectedStock || stocks[0];

  return (
    <div className="space-y-6">
      {/* Top Controls: Search, Sector, Sort */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-blue-600" />
              <span>Stock Screener & Market Explorer</span>
            </h2>
            <p className="text-xs text-slate-500">
              Browse top Indian equities, analyze Level 2 order books, and simulate positions
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search ticker or company name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Filter Strip */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Sector Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-slate-400 font-medium mr-1 flex items-center gap-1">
              <Filter className="w-3 h-3" />
              Sector:
            </span>
            {sectors.slice(0, 6).map((sector) => (
              <button
                key={sector}
                onClick={() => setSelectedSector(sector)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                  selectedSector === sector
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {sector}
              </button>
            ))}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-2.5 py-1 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500"
            >
              <option value="default">Default Sort</option>
              <option value="gainers">Top Gainers (%)</option>
              <option value="losers">Top Losers (%)</option>
              <option value="volume">Highest Volume</option>
              <option value="price">Highest Price</option>
            </select>
          </div>
        </div>
      </div>

      {/* Stock Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((stock) => {
          const isPositive = stock.change >= 0;
          const isSelected = activeStock.symbol === stock.symbol;

          return (
            <div
              key={stock.symbol}
              onClick={() => setSelectedStock(stock)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-blue-50/40 dark:bg-blue-950/20 border-blue-500 shadow-xs'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-sm text-slate-900 dark:text-white">
                      {stock.symbol}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.2 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded font-mono">
                      {stock.exchange}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 truncate max-w-[180px] mt-0.5">
                    {stock.name}
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-mono tabular-nums font-bold text-sm text-slate-900 dark:text-white">
                    ₹{stock.currentPrice.toFixed(2)}
                  </div>
                  <div
                    className={`font-mono tabular-nums text-xs font-semibold ${
                      isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {isPositive ? '+' : ''}
                    {stock.change.toFixed(2)} ({isPositive ? '+' : ''}
                    {stock.changePercent.toFixed(2)}%)
                  </div>
                </div>
              </div>

              {/* Fundamentals Row */}
              <div className="grid grid-cols-3 gap-2 pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80 text-[11px] font-mono tabular-nums text-slate-500">
                <div>
                  <span className="font-sans text-[10px] text-slate-400 block">Mkt Cap</span>
                  <span>{stock.marketCap}</span>
                </div>
                <div>
                  <span className="font-sans text-[10px] text-slate-400 block">P/E Ratio</span>
                  <span>{stock.peRatio}</span>
                </div>
                <div>
                  <span className="font-sans text-[10px] text-slate-400 block">Volume</span>
                  <span>{(stock.volume / 100000).toFixed(1)}L</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-3 mt-2 border-t border-slate-100 dark:border-slate-800/80">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    openOrderModal(stock, 'BUY');
                  }}
                  className="flex-1 py-1.5 rounded-lg bg-[#4184f3] hover:bg-blue-700 text-white font-bold text-xs transition-colors"
                >
                  BUY
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    openOrderModal(stock, 'SELL');
                  }}
                  className="flex-1 py-1.5 rounded-lg bg-[#ff5722] hover:bg-orange-700 text-white font-bold text-xs transition-colors"
                >
                  SELL
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    addStockToWatchlist(stock.symbol);
                  }}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
                  title={`Add to Watchlist ${activeWatchlistTab}`}
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Stock Inspection (Chart & Market Depth) */}
      {activeStock && (
        <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Technical Overview: {activeStock.name} ({activeStock.symbol})
            </h3>
            <span className="text-xs text-slate-500">Live Simulated Feeds</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <StockPriceChart stock={activeStock} />
            </div>
            <div>
              <MarketDepthTable
                depth={activeStock.depth}
                openPrice={activeStock.openPrice}
                highPrice={activeStock.highPrice}
                lowPrice={activeStock.lowPrice}
                prevClose={activeStock.prevClose}
                week52High={activeStock.week52High}
                week52Low={activeStock.week52Low}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
