import React from 'react';
import { Layers, AlertCircle, RefreshCw } from 'lucide-react';
import { useTrading } from '../context/TradingContext.tsx';
import { formatINR, formatPercent } from '../utils/calculations.ts';

export const PositionsPage: React.FC = () => {
  const { positions, squareOffPosition } = useTrading();

  const openPositions = positions.filter((p) => p.status === 'OPEN');
  const totalPositionsPnL = openPositions.reduce((acc, p) => acc + p.pnl, 0);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-blue-600" />
              <span>Positions ({openPositions.length})</span>
            </h2>
            <p className="text-xs text-slate-500">
              Intraday Margin (MIS) active trades with Mark-to-Market (MTM) calculations
            </p>
          </div>

          <div className="text-right">
            <span className="text-[11px] text-slate-400 block font-sans">Total MTM P&L</span>
            <span
              className={`font-mono tabular-nums text-base font-bold ${
                totalPositionsPnL >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {formatINR(totalPositionsPnL, true)}
            </span>
          </div>
        </div>

        <div className="pt-3 text-xs text-slate-500 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-blue-500 shrink-0" />
          <span>
            Intraday positions are auto-squared off at market close (3:20 PM IST). 5x leverage applied on initial margin.
          </span>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        {openPositions.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <p className="font-semibold text-sm text-slate-700 dark:text-slate-300">No open positions</p>
            <p className="mt-1">
              Select any stock from your watchlist and place an Intraday (MIS) trade to view live positions here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold">
                  <th className="py-3 px-4">Instrument</th>
                  <th className="py-3 px-3">Product</th>
                  <th className="py-3 px-3 text-right">Qty</th>
                  <th className="py-3 px-3 text-right">Entry Price</th>
                  <th className="py-3 px-3 text-right">LTP (₹)</th>
                  <th className="py-3 px-3 text-right">MTM P&L (₹)</th>
                  <th className="py-3 px-3 text-right">Chg%</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono tabular-nums">
                {openPositions.map((pos) => {
                  const isPositive = pos.pnl >= 0;

                  return (
                    <tr key={pos.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4">
                        <div className="font-sans font-bold text-slate-900 dark:text-slate-100">
                          {pos.symbol}
                        </div>
                        <div className="font-sans text-[11px] text-slate-400">
                          {pos.stockName}
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-sans px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-50 dark:bg-blue-950 text-blue-600">
                          {pos.product}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-semibold text-slate-800 dark:text-slate-200">
                        {pos.quantity}
                      </td>
                      <td className="py-3 px-3 text-right text-slate-600 dark:text-slate-400">
                        ₹{pos.buyPrice.toFixed(2)}
                      </td>
                      <td className="py-3 px-3 text-right font-semibold text-slate-900 dark:text-slate-100">
                        ₹{pos.currentPrice.toFixed(2)}
                      </td>
                      <td
                        className={`py-3 px-3 text-right font-bold ${
                          isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {isPositive ? '+' : ''}
                        {formatINR(pos.pnl)}
                      </td>
                      <td
                        className={`py-3 px-3 text-right font-semibold ${
                          isPositive ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        {formatPercent(pos.pnlPercent)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => squareOffPosition(pos.symbol)}
                          className="px-2.5 py-1 rounded bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400 hover:bg-rose-600 hover:text-white font-sans text-xs font-semibold transition-colors"
                        >
                          Square Off
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
