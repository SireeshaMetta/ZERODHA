import React, { useState } from 'react';
import { FileText, CheckCircle2, Clock, XCircle, Search, Play, X } from 'lucide-react';
import { useTrading } from '../context/TradingContext.tsx';
import { OrderStatus, OrderSide } from '../types/index.ts';
import { formatINR } from '../utils/calculations.ts';

export const OrdersPage: React.FC = () => {
  const { orders, cancelOrder, simulateLimitFill } = useTrading();
  const [activeTab, setActiveTab] = useState<'ALL' | 'PENDING' | 'COMPLETED' | 'CANCELLED'>('ALL');
  const [searchFilter, setSearchFilter] = useState('');
  const [sideFilter, setSideFilter] = useState<'ALL' | OrderSide>('ALL');

  const pendingCount = orders.filter((o) => o.status === 'PENDING').length;
  const completedCount = orders.filter((o) => o.status === 'COMPLETED').length;
  const cancelledCount = orders.filter((o) => o.status === 'CANCELLED').length;

  const filteredOrders = orders.filter((o) => {
    if (activeTab !== 'ALL' && o.status !== activeTab) return false;
    if (sideFilter !== 'ALL' && o.side !== sideFilter) return false;
    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase();
      return (
        o.symbol.toLowerCase().includes(q) ||
        o.orderId.toLowerCase().includes(q) ||
        o.stockName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <span>Order Book ({orders.length})</span>
            </h2>
            <p className="text-xs text-slate-500">
              Real-time simulated order management supporting Market fills and Limit price matching
            </p>
          </div>

          {/* Quick Filters */}
          <div className="flex items-center gap-3">
            <div className="relative w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search orders..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            <select
              value={sideFilter}
              onChange={(e) => setSideFilter(e.target.value as any)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">All Sides</option>
              <option value="BUY">BUY Only</option>
              <option value="SELL">SELL Only</option>
            </select>
          </div>
        </div>

        {/* Status Tabs */}
        <div className="flex items-center gap-2 pt-4">
          {[
            { id: 'ALL', label: 'All Orders', count: orders.length },
            { id: 'PENDING', label: 'Open / Pending', count: pendingCount, icon: Clock },
            { id: 'COMPLETED', label: 'Executed', count: completedCount, icon: CheckCircle2 },
            { id: 'CANCELLED', label: 'Cancelled', count: cancelledCount, icon: XCircle },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-900'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <span>{tab.label}</span>
              <span className="font-mono text-[10px] opacity-75">({tab.count})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        {filteredOrders.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <p className="font-semibold text-sm text-slate-700 dark:text-slate-300">No orders match filter</p>
            <p className="mt-1">
              {activeTab === 'PENDING'
                ? 'No pending limit orders waiting in the order book.'
                : 'No orders have been recorded in this category.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold">
                  <th className="py-3 px-4">Time</th>
                  <th className="py-3 px-3">Order ID</th>
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3">Instrument</th>
                  <th className="py-3 px-3">Product</th>
                  <th className="py-3 px-3">Side</th>
                  <th className="py-3 px-3 text-right">Qty</th>
                  <th className="py-3 px-3 text-right">Price</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono tabular-nums">
                {filteredOrders.map((order) => {
                  const isBuy = order.side === 'BUY';
                  const isPending = order.status === 'PENDING';
                  const isCompleted = order.status === 'COMPLETED';

                  return (
                    <tr
                      key={order.orderId}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3 px-4 text-slate-500 font-sans text-[11px]">
                        {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400">{order.orderId}</td>
                      <td className="py-3 px-3">
                        <span className="font-sans px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {order.type}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-sans font-bold text-slate-900 dark:text-slate-100">
                          {order.symbol}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-500 font-sans text-[11px]">{order.product}</td>
                      <td className="py-3 px-3 font-sans">
                        <span
                          className={`font-semibold ${
                            isBuy ? 'text-blue-600' : 'text-orange-600'
                          }`}
                        >
                          {order.side}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-semibold text-slate-800 dark:text-slate-200">
                        {order.quantity}
                      </td>
                      <td className="py-3 px-3 text-right">
                        ₹{(order.executedPrice || order.price).toFixed(2)}
                      </td>
                      <td className="py-3 px-3 text-center font-sans">
                        <span
                          className={`text-[11px] font-semibold ${
                            isCompleted
                              ? 'text-emerald-600'
                              : isPending
                              ? 'text-amber-600'
                              : 'text-rose-600'
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-sans">
                        {isPending && (
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Simulate trigger button for interview demo */}
                            <button
                              onClick={() => simulateLimitFill(order.orderId)}
                              className="px-2 py-1 rounded bg-blue-50 dark:bg-blue-950 text-blue-600 hover:bg-blue-600 hover:text-white text-[11px] font-semibold transition-colors flex items-center gap-1"
                              title="Force match & fill limit order for demo"
                            >
                              <Play className="w-3 h-3" />
                              <span>Fill Limit</span>
                            </button>

                            {/* Cancel order */}
                            <button
                              onClick={() => cancelOrder(order.orderId)}
                              className="p-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-rose-100 hover:text-rose-600 text-slate-500 transition-colors"
                              title="Cancel pending order"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
