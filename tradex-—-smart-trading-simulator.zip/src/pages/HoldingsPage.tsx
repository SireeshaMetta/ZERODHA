import React, { useState } from 'react';
import { Briefcase, ArrowUpRight, ArrowDownRight, Plus, Minus, Search } from 'lucide-react';
import { useTrading } from '../context/TradingContext.tsx';
import { formatINR, formatPercent } from '../utils/calculations.ts';
import { AllocationPieChart } from '../components/charts/AllocationPieChart.tsx';

export const HoldingsPage: React.FC = () => {
  const { holdings, holdingsSummary, stocks, openOrderModal, setSelectedStock } = useTrading();
  const [filterText, setFilterText] = useState('');

  const filteredHoldings = holdings.filter(
    (h) =>
      h.symbol.toLowerCase().includes(filterText.toLowerCase()) ||
      h.stockName.toLowerCase().includes(filterText.toLowerCase())
  );

  const totalPnLPositive = holdingsSummary.totalPnL >= 0;
  const totalDayPnLPositive = holdingsSummary.totalDayPnL >= 0;

  return (
    <div className="space-y-6">
      {/* Header & Metric Strip */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-blue-600" />
              <span>Holdings ({holdings.length})</span>
            </h2>
            <p className="text-xs text-slate-500">
              Long-term equity investments (CNC) with live weighted average purchase calculations
            </p>
          </div>

          {/* Quick Search inside holdings */}
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search holdings..."
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Aggregate KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 text-xs font-mono tabular-nums">
          <div>
            <span className="text-slate-400 font-sans block text-[11px]">Total Investment</span>
            <span className="text-base font-bold text-slate-900 dark:text-slate-100">
              {formatINR(holdingsSummary.totalInvested)}
            </span>
          </div>

          <div>
            <span className="text-slate-400 font-sans block text-[11px]">Current Market Value</span>
            <span className="text-base font-bold text-slate-900 dark:text-slate-100">
              {formatINR(holdingsSummary.totalCurrentValue)}
            </span>
          </div>

          <div>
            <span className="text-slate-400 font-sans block text-[11px]">Total Unrealized P&L</span>
            <span
              className={`text-base font-bold ${
                totalPnLPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {formatINR(holdingsSummary.totalPnL, true)} ({formatPercent(holdingsSummary.totalPnLPercent)})
            </span>
          </div>

          <div>
            <span className="text-slate-400 font-sans block text-[11px]">Day's P&L</span>
            <span
              className={`text-base font-bold ${
                totalDayPnLPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {formatINR(holdingsSummary.totalDayPnL, true)}
            </span>
          </div>
        </div>
      </div>

      {/* Holdings Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        {filteredHoldings.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <p className="font-semibold text-sm text-slate-700 dark:text-slate-300">No holdings found</p>
            <p className="mt-1">
              You haven't bought any CNC shares yet. Use the Watchlist on the left to Buy shares with your virtual cash!
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold">
                  <th className="py-3 px-4">Instrument</th>
                  <th className="py-3 px-3 text-right">Qty</th>
                  <th className="py-3 px-3 text-right">Avg. Cost</th>
                  <th className="py-3 px-3 text-right">LTP (₹)</th>
                  <th className="py-3 px-3 text-right">Cur. Val</th>
                  <th className="py-3 px-3 text-right">P&L (₹)</th>
                  <th className="py-3 px-3 text-right">Net Chg%</th>
                  <th className="py-3 px-3 text-right">Day Chg</th>
                  <th className="py-3 px-4 text-center">Quick Trade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono tabular-nums">
                {filteredHoldings.map((h) => {
                  const stock = stocks.find((s) => s.symbol === h.symbol);
                  const isPnLPositive = h.unrealizedPnL >= 0;
                  const isDayPositive = h.dayPnL >= 0;

                  return (
                    <tr
                      key={h.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      {/* Instrument */}
                      <td className="py-3 px-4">
                        <div
                          className="cursor-pointer"
                          onClick={() => {
                            if (stock) setSelectedStock(stock);
                          }}
                        >
                          <div className="font-sans font-bold text-slate-900 dark:text-slate-100 hover:text-blue-600 transition-colors">
                            {h.symbol}
                          </div>
                          <div className="font-sans text-[11px] text-slate-400 truncate max-w-[140px]">
                            {h.stockName}
                          </div>
                        </div>
                      </td>

                      {/* Quantity */}
                      <td className="py-3 px-3 text-right font-semibold text-slate-800 dark:text-slate-200">
                        {h.quantity}
                      </td>

                      {/* Average Cost */}
                      <td className="py-3 px-3 text-right text-slate-600 dark:text-slate-400">
                        ₹{h.averagePrice.toFixed(2)}
                      </td>

                      {/* Last Traded Price */}
                      <td className="py-3 px-3 text-right font-semibold text-slate-900 dark:text-slate-100">
                        ₹{h.currentPrice.toFixed(2)}
                      </td>

                      {/* Current Value */}
                      <td className="py-3 px-3 text-right text-slate-800 dark:text-slate-200">
                        ₹{h.currentValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Unrealized P&L */}
                      <td
                        className={`py-3 px-3 text-right font-bold ${
                          isPnLPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {isPnLPositive ? '+' : ''}
                        {formatINR(h.unrealizedPnL)}
                      </td>

                      {/* Net Change % */}
                      <td
                        className={`py-3 px-3 text-right font-semibold ${
                          isPnLPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {formatPercent(h.unrealizedPnLPercent)}
                      </td>

                      {/* Day Change */}
                      <td
                        className={`py-3 px-3 text-right ${
                          isDayPositive ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        {isDayPositive ? '+' : ''}
                        {formatINR(h.dayPnL)}
                      </td>

                      {/* Quick Trade Buttons */}
                      <td className="py-3 px-4 text-center">
                        <div className="inline-flex items-center gap-1 font-sans">
                          {stock && (
                            <>
                              <button
                                onClick={() => openOrderModal(stock, 'BUY')}
                                className="px-2 py-1 bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 hover:bg-blue-600 hover:text-white rounded text-[11px] font-semibold transition-colors flex items-center gap-1"
                                title="Add more shares"
                              >
                                <Plus className="w-3 h-3" />
                                <span>Add</span>
                              </button>
                              <button
                                onClick={() => openOrderModal(stock, 'SELL')}
                                className="px-2 py-1 bg-orange-50 dark:bg-orange-950 text-orange-600 dark:text-orange-400 hover:bg-orange-600 hover:text-white rounded text-[11px] font-semibold transition-colors flex items-center gap-1"
                                title="Sell shares"
                              >
                                <Minus className="w-3 h-3" />
                                <span>Exit</span>
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Bottom Section: Allocation Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
          <h4 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Weighted Average Cost Methodology
          </h4>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            When buying additional shares of an already held equity, TradeX dynamically recomputes the new average purchase cost using exact volume-weighted averaging:
          </p>
          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 font-mono text-[11px] text-slate-700 dark:text-slate-300">
            AvgCost = [(ExistingShares × ExistingAvg) + (NewShares × NewPrice)] / (ExistingShares + NewShares)
          </div>
          <p className="text-xs text-slate-500">
            Upon partial or full sell orders, realized profit/loss is locked into your trade ledger based on this average cost basis.
          </p>
        </div>

        <AllocationPieChart holdings={holdings} />
      </div>
    </div>
  );
};
