import React, { useState } from 'react';
import { History, Download, Search, Filter } from 'lucide-react';
import { useTrading } from '../context/TradingContext.tsx';
import { formatINR } from '../utils/calculations.ts';

export const TradeHistoryPage: React.FC = () => {
  const { transactions } = useTrading();
  const [symbolFilter, setSymbolFilter] = useState('');
  const [sideFilter, setSideFilter] = useState<'ALL' | 'BUY' | 'SELL'>('ALL');

  const filteredTransactions = transactions.filter((t) => {
    if (sideFilter !== 'ALL' && t.side !== sideFilter) return false;
    if (symbolFilter.trim()) {
      const q = symbolFilter.toLowerCase();
      return (
        t.symbol.toLowerCase().includes(q) ||
        t.orderId.toLowerCase().includes(q) ||
        t.stockName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const exportCSV = () => {
    if (filteredTransactions.length === 0) return;

    const headers = ['Transaction ID', 'Order ID', 'Timestamp', 'Symbol', 'Stock Name', 'Side', 'Product', 'Quantity', 'Price (INR)', 'Total Amount (INR)', 'Realized PnL (INR)'];
    const rows = filteredTransactions.map((t) => [
      t.id,
      t.orderId,
      t.timestamp,
      t.symbol,
      `"${t.stockName}"`,
      t.side,
      t.product,
      t.quantity,
      t.price,
      t.totalAmount,
      t.realizedPnL !== undefined ? t.realizedPnL : '',
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `tradex_trade_history_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <History className="w-5 h-5 text-blue-600" />
              <span>Trade History & Ledger ({transactions.length})</span>
            </h2>
            <p className="text-xs text-slate-500">
              Audit log of all executed trades with verified realized profit/loss calculations
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Search */}
            <div className="relative w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search trades..."
                value={symbolFilter}
                onChange={(e) => setSymbolFilter(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Side filter */}
            <select
              value={sideFilter}
              onChange={(e) => setSideFilter(e.target.value as any)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">All Actions</option>
              <option value="BUY">BUY Only</option>
              <option value="SELL">SELL Only</option>
            </select>

            {/* CSV Export Button */}
            <button
              onClick={exportCSV}
              disabled={filteredTransactions.length === 0}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        {filteredTransactions.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <p className="font-semibold text-sm text-slate-700 dark:text-slate-300">No transactions recorded</p>
            <p className="mt-1">
              Executed orders will automatically generate an immutable ledger record here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold">
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-3">Order Ref</th>
                  <th className="py-3 px-3">Instrument</th>
                  <th className="py-3 px-3">Side</th>
                  <th className="py-3 px-3">Product</th>
                  <th className="py-3 px-3 text-right">Shares</th>
                  <th className="py-3 px-3 text-right">Exec. Price</th>
                  <th className="py-3 px-3 text-right">Total Turn (₹)</th>
                  <th className="py-3 px-4 text-right">Realized P&L</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono tabular-nums">
                {filteredTransactions.map((t) => {
                  const isBuy = t.side === 'BUY';
                  const hasRealizedPnL = t.realizedPnL !== undefined;
                  const isPnLPositive = (t.realizedPnL || 0) >= 0;

                  return (
                    <tr
                      key={t.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3 px-4 text-slate-500 font-sans text-[11px]">
                        {new Date(t.timestamp).toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-slate-500">{t.orderId}</td>
                      <td className="py-3 px-3 font-sans">
                        <div className="font-bold text-slate-900 dark:text-slate-100">{t.symbol}</div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[120px]">{t.stockName}</div>
                      </td>
                      <td className="py-3 px-3 font-sans">
                        <span
                          className={`font-semibold ${
                            isBuy ? 'text-blue-600' : 'text-orange-600'
                          }`}
                        >
                          {t.side}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-500 font-sans text-[11px]">{t.product}</td>
                      <td className="py-3 px-3 text-right font-semibold text-slate-800 dark:text-slate-200">
                        {t.quantity}
                      </td>
                      <td className="py-3 px-3 text-right">₹{t.price.toFixed(2)}</td>
                      <td className="py-3 px-3 text-right font-semibold text-slate-900 dark:text-slate-100">
                        ₹{t.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-4 text-right">
                        {hasRealizedPnL ? (
                          <span
                            className={`font-bold ${
                              isPnLPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                            }`}
                          >
                            {isPnLPositive ? '+' : ''}
                            {formatINR(t.realizedPnL!)}
                          </span>
                        ) : (
                          <span className="text-slate-400 font-sans text-[11px]">Holdings Acquired</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
