import React, { useState } from 'react';
import { User as UserIcon, Settings, Shield, Terminal, Key, Database, RefreshCw, Moon, Sun, CheckCircle, Cpu } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { useTrading } from '../context/TradingContext.tsx';
import { useTheme } from '../context/ThemeContext.tsx';
import { formatINR } from '../utils/calculations.ts';
import api from '../services/api.ts';

export const ProfileSettingsPage: React.FC = () => {
  const { user, logout, demoLogin } = useAuth();
  const { storageStatus, isSimulatingTicks, togglePriceSimulation, addToast } = useTrading();
  const { theme, toggleTheme } = useTheme();
  const [apiTestResponse, setApiTestResponse] = useState<string | null>(null);
  const [isTestingApi, setIsTestingApi] = useState(false);

  const testHealthEndpoint = async () => {
    setIsTestingApi(true);
    try {
      const res = await api.get('/health');
      setApiTestResponse(JSON.stringify(res.data, null, 2));
      addToast('success', 'REST API Verified', 'Connected to backend server endpoint /api/health successfully.');
    } catch (err: any) {
      setApiTestResponse(`Error: ${err.message}`);
      addToast('error', 'API Test Failed', err.message);
    } finally {
      setIsTestingApi(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header Profile Card */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-blue-500 shadow-sm shrink-0">
              <img
                src="/src/assets/images/trader_avatar_1792393502552.jpg"
                alt="Profile"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  {user?.name || 'Metta Sireesha'}
                </h2>
                <span className="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-mono text-xs font-bold">
                  {user?.clientCode || 'TX9082'}
                </span>
              </div>
              <div className="text-xs text-slate-500 mt-1">{user?.email || 'demo@tradex.com'}</div>
              <div className="text-[11px] text-slate-400 mt-1">
                Paper Trader · Zerodha Kite Terminal Mode
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => demoLogin()}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset to Demo User</span>
            </button>
            <button
              onClick={() => logout()}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 dark:text-rose-400 transition-colors"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Trading Terminal Preferences */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <h3 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Settings className="w-4 h-4 text-blue-600" />
            <span>Terminal Preferences</span>
          </h3>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {/* Theme Toggle */}
            <div className="py-3 flex items-center justify-between">
              <div>
                <div className="font-semibold text-slate-800 dark:text-slate-200">Color Appearance</div>
                <div className="text-slate-500 text-[11px]">Toggle between Crisp Light and OLED Dark theme</div>
              </div>
              <button
                onClick={toggleTheme}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
                <span className="capitalize">{theme} Mode</span>
              </button>
            </div>

            {/* Live Ticks Toggle */}
            <div className="py-3 flex items-center justify-between">
              <div>
                <div className="font-semibold text-slate-800 dark:text-slate-200">Real-time Ticks Engine</div>
                <div className="text-slate-500 text-[11px]">Continuous price simulation every ~3 seconds</div>
              </div>
              <button
                onClick={togglePriceSimulation}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  isSimulatingTicks
                    ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 border border-emerald-200 dark:border-emerald-900'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                }`}
              >
                {isSimulatingTicks ? 'Enabled (Active)' : 'Paused'}
              </button>
            </div>

            {/* Starting Virtual Balance */}
            <div className="py-3 flex items-center justify-between">
              <div>
                <div className="font-semibold text-slate-800 dark:text-slate-200">Starting Paper Capital</div>
                <div className="text-slate-500 text-[11px]">Default allocation for training</div>
              </div>
              <span className="font-mono tabular-nums font-bold text-slate-900 dark:text-slate-100">
                ₹10,00,000.00
              </span>
            </div>
          </div>
        </div>

        {/* Backend & Architecture Specs */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <h3 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-600" />
            <span>Full-Stack Architecture Diagnostics</span>
          </h3>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-lg border border-slate-200 dark:border-slate-700 text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Server Framework:</span>
              <span className="font-semibold text-slate-700 dark:text-slate-300">Express.js (Node.js + TypeScript)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Data Layer Mode:</span>
              <span className="font-semibold text-blue-600 dark:text-blue-400">{storageStatus.mode}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Authentication:</span>
              <span className="font-semibold text-slate-700 dark:text-slate-300">JWT + bcrypt password hashing</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Trading Engine:</span>
              <span className="font-semibold text-slate-700 dark:text-slate-300">Market Fills & Limit Price Matcher</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={testHealthEndpoint}
              disabled={isTestingApi}
              className="w-full py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>{isTestingApi ? 'Probing /api/health...' : 'Test Backend REST API (/api/health)'}</span>
            </button>
            {apiTestResponse && (
              <pre className="mt-3 p-3 bg-slate-950 text-emerald-400 font-mono text-[11px] rounded-lg overflow-x-auto max-h-36">
                {apiTestResponse}
              </pre>
            )}
          </div>
        </div>
      </div>

      {/* Keyboard Shortcuts Reference */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
        <h3 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider">
          Zerodha Kite Fast Trader Shortcuts
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg flex items-center justify-between">
            <span className="text-slate-500">Buy Stock</span>
            <kbd className="px-2 py-0.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded font-mono font-bold text-blue-600">
              B
            </kbd>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg flex items-center justify-between">
            <span className="text-slate-500">Sell Stock</span>
            <kbd className="px-2 py-0.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded font-mono font-bold text-orange-600">
              S
            </kbd>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg flex items-center justify-between">
            <span className="text-slate-500">Search Stocks</span>
            <kbd className="px-2 py-0.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded font-mono font-bold text-slate-700 dark:text-slate-300">
              /
            </kbd>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg flex items-center justify-between">
            <span className="text-slate-500">Close Window</span>
            <kbd className="px-2 py-0.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded font-mono font-bold text-slate-700 dark:text-slate-300">
              ESC
            </kbd>
          </div>
        </div>
      </div>
    </div>
  );
};
