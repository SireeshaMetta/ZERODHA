import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, TrendingUp, TrendingDown, Plus, Info, ShieldCheck } from 'lucide-react';
import { useTrading } from '../context/TradingContext.tsx';
import { StockPriceChart } from '../components/charts/StockPriceChart.tsx';
import { MarketDepthTable } from '../components/charts/MarketDepthTable.tsx';
import { formatINR, formatPercent } from '../utils/calculations.ts';

export const StockDetailPage: React.FC = () => {
  const { symbol } = useParams<{ symbol: string }>();
  const { stocks, openOrderModal, addStockToWatchlist, activeWatchlistTab } = useTrading();

  const stock = stocks.find((s) => s.symbol.toUpperCase() === (symbol || '').toUpperCase()) || stocks[0];
  const isPositive = stock.change >= 0;

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Header Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5">
        <div className="flex items-center gap-3 text-xs text-slate-500 mb-3">
          <Link to="/watchlist" className="flex items-center gap-1 hover:text-blue-600 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Screener</span>
          </Link>
          <span aria-hidden="true">/</span>
          <span className="font-semibold text-slate-800 dark:text-slate-200">{stock.symbol}</span>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{stock.symbol}</h1>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
                {stock.exchange}
              </span>
              <span className="text-xs text-slate-400">· {stock.sector}</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">{stock.name}</div>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-right">
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                ₹{stock.currentPrice.toFixed(2)}
              </div>
              <div
                className={`text-xs font-mono tabular-nums font-semibold ${
                  isPositive ? 'text-emerald-600' : 'text-rose-600'
                }`}
              >
                {isPositive ? '+' : ''}
                {stock.change.toFixed(2)} ({isPositive ? '+' : ''}
                {stock.changePercent.toFixed(2)}%)
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => openOrderModal(stock, 'BUY')}
                className="px-5 py-2.5 bg-[#4184f3] hover:bg-blue-700 text-white font-bold text-xs rounded-lg transition-colors shadow-xs"
              >
                BUY [B]
              </button>
              <button
                onClick={() => openOrderModal(stock, 'SELL')}
                className="px-5 py-2.5 bg-[#ff5722] hover:bg-orange-700 text-white font-bold text-xs rounded-lg transition-colors shadow-xs"
              >
                SELL [S]
              </button>
              <button
                onClick={() => addStockToWatchlist(stock.symbol)}
                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
                title={`Pin to Watchlist ${activeWatchlistTab}`}
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Chart & Depth Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <StockPriceChart stock={stock} />

          {/* Company Analytics & Metrics */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <h3 className="font-semibold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              Company Fundamentals & Profile
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono tabular-nums text-xs">
              <div>
                <span className="font-sans text-[11px] text-slate-400 block">Market Capitalization</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{stock.marketCap}</span>
              </div>
              <div>
                <span className="font-sans text-[11px] text-slate-400 block">P/E Ratio (TTM)</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{stock.peRatio}</span>
              </div>
              <div>
                <span className="font-sans text-[11px] text-slate-400 block">52 Week High</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">₹{stock.week52High.toFixed(2)}</span>
              </div>
              <div>
                <span className="font-sans text-[11px] text-slate-400 block">52 Week Low</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">₹{stock.week52Low.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        <div>
          <MarketDepthTable
            depth={stock.depth}
            openPrice={stock.openPrice}
            highPrice={stock.highPrice}
            lowPrice={stock.lowPrice}
            prevClose={stock.prevClose}
            week52High={stock.week52High}
            week52Low={stock.week52Low}
          />
        </div>
      </div>
    </div>
  );
};
