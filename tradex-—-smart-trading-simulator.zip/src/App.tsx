import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext.tsx';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { TradingProvider, useTrading } from './context/TradingContext.tsx';
import { Navbar } from './components/common/Navbar.tsx';
import { WatchlistSidebar } from './components/common/WatchlistSidebar.tsx';
import { DisclaimerBanner } from './components/common/DisclaimerBanner.tsx';
import { QuickOrderModal } from './components/common/QuickOrderModal.tsx';
import { ToastContainer } from './components/common/Toast.tsx';
import { UnitTestModal } from './components/common/UnitTestModal.tsx';

// Pages
import { DashboardPage } from './pages/DashboardPage.tsx';
import { OrdersPage } from './pages/OrdersPage.tsx';
import { HoldingsPage } from './pages/HoldingsPage.tsx';
import { PositionsPage } from './pages/PositionsPage.tsx';
import { FundsPage } from './pages/FundsPage.tsx';
import { TradeHistoryPage } from './pages/TradeHistoryPage.tsx';
import { WatchlistPage } from './pages/WatchlistPage.tsx';
import { StockDetailPage } from './pages/StockDetailPage.tsx';
import { ProfileSettingsPage } from './pages/ProfileSettingsPage.tsx';
import { LoginPage } from './pages/LoginPage.tsx';
import { RegisterPage } from './pages/RegisterPage.tsx';
import { NotFoundPage } from './pages/NotFoundPage.tsx';

function MainLayout() {
  const location = useLocation();
  const { selectedStock, openOrderModal, orderModal, closeOrderModal } = useTrading();

  const isAuthPage = location.pathname === '/login' || location.pathname === '/register';

  // Global Keyboard Shortcuts (Zerodha Kite Style)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Do not trigger shortcuts if user is typing in an input or textarea
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT') {
        return;
      }

      if (e.key === 'Escape' && orderModal.isOpen) {
        closeOrderModal();
      } else if ((e.key === 'b' || e.key === 'B') && selectedStock && !orderModal.isOpen) {
        e.preventDefault();
        openOrderModal(selectedStock, 'BUY');
      } else if ((e.key === 's' || e.key === 'S') && selectedStock && !orderModal.isOpen) {
        e.preventDefault();
        openOrderModal(selectedStock, 'SELL');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedStock, orderModal.isOpen, openOrderModal, closeOrderModal]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      <Navbar />
      <DisclaimerBanner />

      {isAuthPage ? (
        <main className="flex-1">
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
          </Routes>
        </main>
      ) : (
        <div className="flex-1 flex flex-col lg:flex-row max-w-[1720px] w-full mx-auto">
          {/* Zerodha Kite Pinned Left Watchlist */}
          <WatchlistSidebar />

          {/* Main Dashboard Canvas */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0">
            <Routes>
              <Route path="/" element={<DashboardPage />} />
              <Route path="/orders" element={<OrdersPage />} />
              <Route path="/holdings" element={<HoldingsPage />} />
              <Route path="/positions" element={<PositionsPage />} />
              <Route path="/funds" element={<FundsPage />} />
              <Route path="/history" element={<TradeHistoryPage />} />
              <Route path="/watchlist" element={<WatchlistPage />} />
              <Route path="/stocks/:symbol" element={<StockDetailPage />} />
              <Route path="/profile" element={<ProfileSettingsPage />} />
              <Route path="/login" element={<Navigate to="/" replace />} />
              <Route path="/register" element={<Navigate to="/" replace />} />
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </main>
        </div>
      )}

      {/* Global Modals & Indicators */}
      <QuickOrderModal />
      <ToastContainer />
      <UnitTestModal />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <TradingProvider>
            <MainLayout />
          </TradingProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
