/**
 * Financial calculation engine for TradeX Trading Simulator
 * Implements accurate weighted-average pricing, realized/unrealized P&L,
 * margin calculations, and Indian Rupee currency formatting.
 */

/**
 * Format a number into Indian Rupee representation (e.g. ₹1,23,456.78 or -₹23,456.00)
 */
export function formatINR(val: number, includeSign = false): string {
  if (val === undefined || val === null || isNaN(val)) return '₹0.00';
  const isNegative = val < 0;
  const absVal = Math.abs(val);
  
  // Format with standard Indian numbering system (Lakhs, Crores)
  const parts = absVal.toFixed(2).split('.');
  let integerPart = parts[0];
  const decimalPart = parts[1];

  let lastThree = integerPart.substring(integerPart.length - 3);
  const otherNumbers = integerPart.substring(0, integerPart.length - 3);
  if (otherNumbers !== '') {
    lastThree = ',' + lastThree;
  }
  const formattedInt = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;
  const formattedNum = `${formattedInt}.${decimalPart}`;

  if (isNegative) {
    return `-₹${formattedNum}`;
  }
  if (includeSign && val > 0) {
    return `+₹${formattedNum}`;
  }
  return `₹${formattedNum}`;
}

/**
 * Format percentage return with explicit + / - sign
 */
export function formatPercent(val: number): string {
  if (val === undefined || val === null || isNaN(val)) return '0.00%';
  const sign = val > 0 ? '+' : '';
  return `${sign}${val.toFixed(2)}%`;
}

/**
 * Calculate new weighted average purchase price when acquiring additional shares
 * Formula: ((Qty_existing * Avg_existing) + (Qty_new * Price_new)) / (Qty_existing + Qty_new)
 */
export function calculateWeightedAverage(
  existingQty: number,
  existingAvg: number,
  newQty: number,
  newPrice: number
): number {
  if (existingQty <= 0) return newPrice;
  if (newQty <= 0) return existingAvg;
  const totalCost = existingQty * existingAvg + newQty * newPrice;
  const totalShares = existingQty + newQty;
  return Number((totalCost / totalShares).toFixed(2));
}

/**
 * Calculate realized profit or loss upon selling shares
 * Formula: (Sell_Price - Buy_Average_Price) * Shares_Sold
 */
export function calculateRealizedPnL(
  sellPrice: number,
  avgBuyPrice: number,
  sellQty: number
): number {
  return Number(((sellPrice - avgBuyPrice) * sellQty).toFixed(2));
}

/**
 * Calculate unrealized profit or loss for open holdings
 * Formula: (Current_Market_Price - Buy_Average_Price) * Shares_Held
 */
export function calculateUnrealizedPnL(
  currentPrice: number,
  avgBuyPrice: number,
  qty: number
): { pnl: number; pnlPercent: number } {
  const pnl = Number(((currentPrice - avgBuyPrice) * qty).toFixed(2));
  const invested = avgBuyPrice * qty;
  const pnlPercent = invested > 0 ? Number(((pnl / invested) * 100).toFixed(2)) : 0;
  return { pnl, pnlPercent };
}

/**
 * Calculate margin required for an order
 * CNC (Delivery / Longterm) requires 100% of order value
 * MIS (Intraday) requires 20% margin (5x leverage typical on Indian exchanges)
 */
export function calculateMarginRequired(
  price: number,
  quantity: number,
  product: 'CNC' | 'MIS'
): number {
  const totalValue = price * quantity;
  if (product === 'MIS') {
    return Number((totalValue * 0.20).toFixed(2));
  }
  return Number(totalValue.toFixed(2));
}

/**
 * Validate order parameters
 */
export function validateOrder(
  side: 'BUY' | 'SELL',
  quantity: number,
  price: number,
  product: 'CNC' | 'MIS',
  availableCash: number,
  holdingQuantity: number
): { valid: boolean; error?: string } {
  if (!quantity || quantity <= 0 || !Number.isInteger(quantity)) {
    return { valid: false, error: 'Quantity must be a positive whole number.' };
  }
  if (!price || price <= 0) {
    return { valid: false, error: 'Price must be greater than zero.' };
  }

  if (side === 'BUY') {
    const requiredFunds = calculateMarginRequired(price, quantity, product);
    if (requiredFunds > availableCash) {
      return {
        valid: false,
        error: `Insufficient virtual cash. Required: ${formatINR(requiredFunds)}, Available: ${formatINR(availableCash)}`,
      };
    }
  } else if (side === 'SELL') {
    if (product === 'CNC' && quantity > holdingQuantity) {
      return {
        valid: false,
        error: `Insufficient holdings. You only hold ${holdingQuantity} shares.`,
      };
    }
  }

  return { valid: true };
}
