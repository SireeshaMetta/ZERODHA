import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../services/api.ts';
import { INITIAL_STOCKS } from '../services/stockData.ts';
import { Stock, Holding, Position, Order, Transaction, WatchlistGroup, ProductType, OrderSide, OrderType } from '../types/index.ts';
import { useAuth } from './AuthContext.tsx';

export interface ToastItem {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  message: string;
}

interface OrderModalConfig {
  isOpen: boolean;
  stock: Stock | null;
  side: OrderSide;
  product: ProductType;
  type: OrderType;
  quantity: number;
  limitPrice: number;
  triggerPrice?: number;
}

interface TradingContextType {
  stocks: Stock[];
  selectedStock: Stock | null;
  setSelectedStock: (stock: Stock | null) => void;
  watchlists: WatchlistGroup[];
  activeWatchlistTab: number;
  setActiveWatchlistTab: (tab: number) => void;
  addStockToWatchlist: (symbol: string, tabIndex?: number) => Promise<void>;
  removeStockFromWatchlist: (symbol: string, tabIndex?: number) => Promise<void>;
  holdings: Holding[];
  holdingsSummary: {
    totalInvested: number;
    totalCurrentValue: number;
    totalPnL: number;
    totalPnLPercent: number;
    totalDayPnL: number;
    totalCount: number;
  };
  positions: Position[];
  orders: Order[];
  transactions: Transaction[];
  funds: {
    availableCash: number;
    usedMargin: number;
    initialCash: number;
    holdingsMarketValue: number;
    totalEquity: number;
  };
  orderModal: OrderModalConfig;
  openOrderModal: (stock: Stock, side?: OrderSide, product?: ProductType, type?: OrderType) => void;
  closeOrderModal: () => void;
  executeTrade: (params: {
    symbol: string;
    side: OrderSide;
    product: ProductType;
    type: OrderType;
    quantity: number;
    price?: number;
    triggerPrice?: number;
  }) => Promise<{ success: boolean; order?: Order; error?: string }>;
  cancelOrder: (orderId: string) => Promise<{ success: boolean; error?: string }>;
  simulateLimitFill: (orderId: string) => Promise<{ success: boolean; error?: string }>;
  squareOffPosition: (symbol: string) => Promise<{ success: boolean; error?: string }>;
  addFunds: (amount: number) => Promise<boolean>;
  resetAccount: () => Promise<boolean>;
  toasts: ToastItem[];
  addToast: (type: 'success' | 'error' | 'info', title: string, message: string) => void;
  removeToast: (id: string) => void;
  refreshAllData: () => Promise<void>;
  storageStatus: { mode: string; isMongoConnected: boolean; database: string };
  isSimulatingTicks: boolean;
  togglePriceSimulation: () => void;
}

const TradingContext = createContext<TradingContextType | undefined>(undefined);

export const TradingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated, refreshUser } = useAuth();
  const [stocks, setStocks] = useState<Stock[]>(INITIAL_STOCKS);
  const [selectedStock, setSelectedStock] = useState<Stock | null>(INITIAL_STOCKS[0]);
  const [activeWatchlistTab, setActiveWatchlistTab] = useState<number>(1);
  const [watchlists, setWatchlists] = useState<WatchlistGroup[]>([
    { id: 1, name: 'Watchlist 1', symbols: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY'] },
    { id: 2, name: 'Watchlist 2', symbols: ['ICICIBANK', 'SBIN', 'TATAMOTORS'] },
    { id: 3, name: 'Watchlist 3', symbols: ['ITC', 'LT', 'BAJFINANCE', 'TITAN'] },
    { id: 4, name: 'Watchlist 4', symbols: [] },
    { id: 5, name: 'Watchlist 5', symbols: [] },
  ]);

  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [holdingsSummary, setHoldingsSummary] = useState({
    totalInvested: 0,
    totalCurrentValue: 0,
    totalPnL: 0,
    totalPnLPercent: 0,
    totalDayPnL: 0,
    totalCount: 0,
  });
  const [positions, setPositions] = useState<Position[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [funds, setFunds] = useState({
    availableCash: 1000000,
    usedMargin: 0,
    initialCash: 1000000,
    holdingsMarketValue: 0,
    totalEquity: 1000000,
  });

  const [storageStatus, setStorageStatus] = useState({
    mode: 'High-Performance Local Hybrid Store',
    isMongoConnected: false,
    database: 'tradex_local_store',
  });

  const [isSimulatingTicks, setIsSimulatingTicks] = useState(true);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Modal State
  const [orderModal, setOrderModal] = useState<OrderModalConfig>({
    isOpen: false,
    stock: null,
    side: 'BUY',
    product: 'CNC',
    type: 'MARKET',
    quantity: 1,
    limitPrice: 0,
  });

  const addToast = useCallback((type: 'success' | 'error' | 'info', title: string, message: string) => {
    const id = 'toast_' + Date.now() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Fetch stocks from server
  const fetchStocks = useCallback(async () => {
    try {
      const res = await api.get('/stocks');
      if (res.data.stocks) {
        setStocks(res.data.stocks);
      }
    } catch (err) {
      // Keep initial stocks
    }
  }, []);

  // Fetch user data
  const refreshAllData = useCallback(async () => {
    if (!isAuthenticated) return;

    try {
      // Parallel requests
      const [hRes, pRes, oRes, fRes, wRes, txRes, healthRes] = await Promise.allSettled([
        api.get('/holdings'),
        api.get('/positions'),
        api.get('/orders'),
        api.get('/funds'),
        api.get('/watchlist'),
        api.get('/funds/transactions'),
        api.get('/health'),
      ]);

      if (hRes.status === 'fulfilled') {
        setHoldings(hRes.value.data.holdings || []);
        if (hRes.value.data.summary) {
          setHoldingsSummary(hRes.value.data.summary);
        }
      }

      if (pRes.status === 'fulfilled') {
        setPositions(pRes.value.data.positions || []);
      }

      if (oRes.status === 'fulfilled') {
        setOrders(oRes.value.data.orders || []);
      }

      if (fRes.status === 'fulfilled') {
        setFunds(fRes.value.data);
      }

      if (wRes.status === 'fulfilled') {
        setWatchlists(wRes.value.data.watchlists || []);
      }

      if (txRes.status === 'fulfilled') {
        setTransactions(txRes.value.data.transactions || []);
      }

      if (healthRes.status === 'fulfilled' && healthRes.value.data.storage) {
        setStorageStatus(healthRes.value.data.storage);
      }
    } catch (err) {
      console.error('Error fetching trading data:', err);
    }
  }, [isAuthenticated]);

  // Sync selectedStock with current price whenever stocks tick
  useEffect(() => {
    if (selectedStock) {
      const current = stocks.find((s) => s.symbol === selectedStock.symbol);
      if (current && (current.currentPrice !== selectedStock.currentPrice || current.volume !== selectedStock.volume)) {
        setSelectedStock(current);
      }
    }
  }, [stocks]);

  // Periodic polling for real-time live prices & pending order fills
  useEffect(() => {
    fetchStocks();
    refreshAllData();

    if (!isSimulatingTicks) return;

    const interval = setInterval(() => {
      fetchStocks();
      // Also update holdings and funds in sync with price moves
      if (isAuthenticated) {
        refreshAllData();
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [fetchStocks, refreshAllData, isSimulatingTicks, isAuthenticated]);

  const openOrderModal = (stock: Stock, side: OrderSide = 'BUY', product: ProductType = 'CNC', type: OrderType = 'MARKET') => {
    setOrderModal({
      isOpen: true,
      stock,
      side,
      product,
      type,
      quantity: 1,
      limitPrice: stock.currentPrice,
    });
  };

  const closeOrderModal = () => {
    setOrderModal((prev) => ({ ...prev, isOpen: false }));
  };

  const executeTrade = async (params: {
    symbol: string;
    side: OrderSide;
    product: ProductType;
    type: OrderType;
    quantity: number;
    price?: number;
    triggerPrice?: number;
  }) => {
    try {
      const res = await api.post('/orders', params);
      const createdOrder = res.data.order;

      if (createdOrder.status === 'COMPLETED') {
        addToast(
          'success',
          `${params.side} Order Executed`,
          `Filled ${params.quantity} ${params.symbol} shares at ₹${createdOrder.executedPrice || params.price}`
        );
      } else {
        addToast(
          'info',
          'Limit Order Placed',
          `Order ${createdOrder.orderId} submitted for ${params.quantity} ${params.symbol} at ₹${params.price}.`
        );
      }

      await refreshAllData();
      await refreshUser();
      closeOrderModal();
      return { success: true, order: createdOrder };
    } catch (err: any) {
      const errMsg = err.response?.data?.error || 'Order execution failed';
      addToast('error', 'Order Rejected', errMsg);
      return { success: false, error: errMsg };
    }
  };

  const cancelOrder = async (orderId: string) => {
    try {
      await api.post(`/orders/${orderId}/cancel`);
      addToast('info', 'Order Cancelled', `Order ${orderId} was cancelled.`);
      await refreshAllData();
      return { success: true };
    } catch (err: any) {
      const errMsg = err.response?.data?.error || 'Failed to cancel order';
      addToast('error', 'Cancellation Failed', errMsg);
      return { success: false, error: errMsg };
    }
  };

  const simulateLimitFill = async (orderId: string) => {
    try {
      const res = await api.post(`/orders/${orderId}/simulate-fill`);
      addToast('success', 'Limit Filled (Demo)', `Pending order ${orderId} triggered and completed!`);
      await refreshAllData();
      await refreshUser();
      return { success: true };
    } catch (err: any) {
      const errMsg = err.response?.data?.error || 'Simulation trigger failed';
      addToast('error', 'Trigger Error', errMsg);
      return { success: false, error: errMsg };
    }
  };

  const squareOffPosition = async (symbol: string) => {
    try {
      await api.post('/positions/square-off', { symbol });
      addToast('success', 'Position Squared Off', `Intraday square off completed for ${symbol}.`);
      await refreshAllData();
      return { success: true };
    } catch (err: any) {
      const errMsg = err.response?.data?.error || 'Square off failed';
      addToast('error', 'Error', errMsg);
      return { success: false, error: errMsg };
    }
  };

  const addStockToWatchlist = async (symbol: string, tabIndex = activeWatchlistTab) => {
    try {
      const res = await api.post('/watchlist', { symbol, tabIndex });
      if (res.data.watchlists) {
        setWatchlists(res.data.watchlists);
      }
      addToast('success', 'Watchlist Updated', `Added ${symbol} to Watchlist ${tabIndex}`);
    } catch (err: any) {
      addToast('error', 'Failed to Add', err.response?.data?.error || 'Error updating watchlist');
    }
  };

  const removeStockFromWatchlist = async (symbol: string, tabIndex = activeWatchlistTab) => {
    try {
      const res = await api.delete(`/watchlist/${tabIndex}/${symbol}`);
      if (res.data.watchlists) {
        setWatchlists(res.data.watchlists);
      }
      addToast('info', 'Removed', `Removed ${symbol} from Watchlist ${tabIndex}`);
    } catch (err: any) {
      addToast('error', 'Failed to Remove', err.response?.data?.error || 'Error removing from watchlist');
    }
  };

  const addFunds = async (amount: number) => {
    try {
      await api.post('/funds/add', { amount });
      addToast('success', 'Funds Deposited', `Credited ₹${amount.toLocaleString('en-IN')} to virtual margin account.`);
      await refreshAllData();
      await refreshUser();
      return true;
    } catch (err: any) {
      addToast('error', 'Deposit Failed', err.response?.data?.error || 'Failed to deposit virtual funds');
      return false;
    }
  };

  const resetAccount = async () => {
    try {
      await api.post('/funds/reset');
      addToast('info', 'Portfolio Reset', 'Paper trading account reset to initial ₹10,00,000 balance.');
      await refreshAllData();
      await refreshUser();
      return true;
    } catch (err: any) {
      addToast('error', 'Reset Failed', err.response?.data?.error || 'Failed to reset account');
      return false;
    }
  };

  const togglePriceSimulation = () => {
    setIsSimulatingTicks((prev) => !prev);
  };

  return (
    <TradingContext.Provider
      value={{
        stocks,
        selectedStock,
        setSelectedStock,
        watchlists,
        activeWatchlistTab,
        setActiveWatchlistTab,
        addStockToWatchlist,
        removeStockFromWatchlist,
        holdings,
        holdingsSummary,
        positions,
        orders,
        transactions,
        funds,
        orderModal,
        openOrderModal,
        closeOrderModal,
        executeTrade,
        cancelOrder,
        simulateLimitFill,
        squareOffPosition,
        addFunds,
        resetAccount,
        toasts,
        addToast,
        removeToast,
        refreshAllData,
        storageStatus,
        isSimulatingTicks,
        togglePriceSimulation,
      }}
    >
      {children}
    </TradingContext.Provider>
  );
};

export function useTrading(): TradingContextType {
  const context = useContext(TradingContext);
  if (!context) {
    throw new Error('useTrading must be used within a TradingProvider');
  }
  return context;
}
