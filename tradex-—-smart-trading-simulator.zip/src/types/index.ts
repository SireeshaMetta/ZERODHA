export type OrderSide = 'BUY' | 'SELL';
export type OrderType = 'MARKET' | 'LIMIT';
export type ProductType = 'CNC' | 'MIS'; // CNC = Cash & Carry (Holdings), MIS = Margin Intraday Square-off
export type OrderStatus = 'PENDING' | 'COMPLETED' | 'CANCELLED' | 'REJECTED';

export interface StockMarketDepthEntry {
  price: number;
  orders: number;
  quantity: number;
}

export interface StockMarketDepth {
  bids: StockMarketDepthEntry[];
  asks: StockMarketDepthEntry[];
  totalBids: number;
  totalAsks: number;
}

export interface HistoricalPoint {
  time: string;
  price: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Stock {
  symbol: string;
  name: string;
  exchange: 'NSE' | 'BSE';
  sector: string;
  currentPrice: number;
  openPrice: number;
  highPrice: number;
  lowPrice: number;
  prevClose: number;
  change: number;
  changePercent: number;
  volume: number;
  week52High: number;
  week52Low: number;
  peRatio: number;
  marketCap: string; // e.g., '₹19.4L Cr'
  historicalData: {
    '1D': HistoricalPoint[];
    '1W': HistoricalPoint[];
    '1M': HistoricalPoint[];
    '3M': HistoricalPoint[];
    '1Y': HistoricalPoint[];
  };
  depth: StockMarketDepth;
}

export interface Holding {
  id: string;
  userId: string;
  symbol: string;
  stockName: string;
  quantity: number;
  averagePrice: number;
  investedValue: number;
  currentPrice: number;
  currentValue: number;
  unrealizedPnL: number;
  unrealizedPnLPercent: number;
  dayPnL: number;
  dayPnLPercent: number;
  updatedAt: string;
}

export interface Position {
  id: string;
  userId: string;
  symbol: string;
  stockName: string;
  product: ProductType;
  quantity: number;
  buyPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  side: OrderSide;
  status: 'OPEN' | 'CLOSED';
}

export interface Order {
  id: string;
  orderId: string;
  userId: string;
  symbol: string;
  stockName: string;
  side: OrderSide;
  product: ProductType;
  type: OrderType;
  quantity: number;
  price: number; // Requested price or execution price
  triggerPrice?: number;
  executedPrice?: number;
  status: OrderStatus;
  statusMessage?: string;
  createdAt: string;
  executedAt?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  orderId: string;
  symbol: string;
  stockName: string;
  side: OrderSide;
  quantity: number;
  price: number;
  totalAmount: number;
  product: ProductType;
  realizedPnL?: number;
  timestamp: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  clientCode: string; // e.g. "TX7890"
  virtualCash: number;
  initialCash: number;
  usedMargin: number;
  createdAt: string;
}

export interface WatchlistGroup {
  id: number;
  name: string;
  symbols: string[];
}

export interface DashboardSummary {
  portfolioValue: number;
  totalInvestment: number;
  overallPnL: number;
  overallPnLPercent: number;
  todayPnL: number;
  todayPnLPercent: number;
  availableCash: number;
  usedMargin: number;
  holdingsCount: number;
  positionsCount: number;
  topGainers: Stock[];
  topLosers: Stock[];
  recentOrders: Order[];
}
