/**
 * Unit Test Suite for TradeX Trading Engine & Portfolio Math
 * Validates:
 * 1. Volume-weighted average purchase price calculations
 * 2. Realized profit and loss calculation on partial and full exits
 * 3. Unrealized return calculations
 * 4. Margin calculations for CNC vs MIS
 * 5. Order validation checks (insufficient funds, insufficient holdings)
 */

import {
  calculateWeightedAverage,
  calculateRealizedPnL,
  calculateUnrealizedPnL,
  calculateMarginRequired,
  validateOrder,
  formatINR,
} from '../utils/calculations.ts';

export interface TestResult {
  suite: string;
  testName: string;
  passed: boolean;
  expected: any;
  actual: any;
  message?: string;
}

export function runTradingEngineTests(): { total: number; passed: number; failed: number; results: TestResult[] } {
  const results: TestResult[] = [];

  function assert(suite: string, testName: string, passed: boolean, expected: any, actual: any, message?: string) {
    results.push({ suite, testName, passed, expected, actual, message });
  }

  // 1. Weighted Average Calculation Tests
  {
    // Buying 10 shares at 100, then 10 shares at 200 => (1000 + 2000)/20 = 150
    const avg1 = calculateWeightedAverage(10, 100, 10, 200);
    assert(
      'Weighted Average',
      'Calculates equal quantity purchase correctly',
      avg1 === 150,
      150,
      avg1
    );

    // Buying 25 shares at 2860, then 15 shares at 2940 => (71500 + 44100)/40 = 115600/40 = 2890
    const avg2 = calculateWeightedAverage(25, 2860, 15, 2940);
    assert(
      'Weighted Average',
      'Calculates unequal multi-lot Reliance purchases correctly',
      avg2 === 2890,
      2890,
      avg2
    );

    // Existing 0 shares, buying 50 at 500 => 500
    const avg3 = calculateWeightedAverage(0, 0, 50, 500);
    assert(
      'Weighted Average',
      'Initial purchase establishes base price',
      avg3 === 500,
      500,
      avg3
    );
  }

  // 2. Realized P&L Calculations
  {
    // Bought at 2860, sold at 2940 for 10 shares => (2940 - 2860) * 10 = 800 profit
    const pnl1 = calculateRealizedPnL(2940, 2860, 10);
    assert(
      'Realized PnL',
      'Calculates profit on profitable exit',
      pnl1 === 800,
      800,
      pnl1
    );

    // Bought at 4150, sold at 4100 for 5 shares => (4100 - 4150) * 5 = -250 loss
    const pnl2 = calculateRealizedPnL(4100, 4150, 5);
    assert(
      'Realized PnL',
      'Calculates loss accurately with negative sign',
      pnl2 === -250,
      -250,
      pnl2
    );
  }

  // 3. Unrealized P&L Calculations
  {
    const res1 = calculateUnrealizedPnL(1870, 1800, 20); // (1870-1800)*20 = 1400, invested = 36000, pct = (1400/36000)*100 = 3.89%
    assert(
      'Unrealized PnL',
      'Calculates open unrealized P&L amount',
      res1.pnl === 1400,
      1400,
      res1.pnl
    );
    assert(
      'Unrealized PnL',
      'Calculates open return percentage',
      res1.pnlPercent === 3.89,
      3.89,
      res1.pnlPercent
    );
  }

  // 4. Margin Calculations (CNC 100% vs MIS 20%)
  {
    const marginCNC = calculateMarginRequired(1000, 10, 'CNC');
    assert(
      'Margin Requirement',
      'CNC requires 100% full cash',
      marginCNC === 10000,
      10000,
      marginCNC
    );

    const marginMIS = calculateMarginRequired(1000, 10, 'MIS');
    assert(
      'Margin Requirement',
      'MIS requires 20% margin (5x leverage)',
      marginMIS === 2000,
      2000,
      marginMIS
    );
  }

  // 5. Order Validation (Insufficient funds & holdings)
  {
    // Sufficient funds
    const v1 = validateOrder('BUY', 10, 500, 'CNC', 10000, 0);
    assert(
      'Order Validation',
      'Validates buy order when funds are sufficient',
      v1.valid === true,
      true,
      v1.valid
    );

    // Insufficient funds
    const v2 = validateOrder('BUY', 100, 2000, 'CNC', 50000, 0); // Requires 200000, only 50000 available
    assert(
      'Order Validation',
      'Rejects buy order with insufficient virtual cash',
      Boolean(v2.valid === false && v2.error?.includes('Insufficient virtual cash')),
      false,
      v2.valid,
      v2.error
    );

    // Selling more shares than held
    const v3 = validateOrder('SELL', 25, 1000, 'CNC', 50000, 10); // Owns 10, trying to sell 25
    assert(
      'Order Validation',
      'Rejects sell order with insufficient holdings',
      Boolean(v3.valid === false && v3.error?.includes('Insufficient holdings')),
      false,
      v3.valid,
      v3.error
    );

    // Invalid negative or zero quantity
    const v4 = validateOrder('BUY', 0, 1000, 'CNC', 50000, 0);
    assert(
      'Order Validation',
      'Rejects zero quantity',
      v4.valid === false,
      false,
      v4.valid
    );
  }

  // 6. Currency Formatter (Indian numbering format)
  {
    const f1 = formatINR(100000);
    assert(
      'Format INR',
      'Formats 1 Lakh with proper comma placement',
      f1 === '₹1,00,000.00',
      '₹1,00,000.00',
      f1
    );

    const f2 = formatINR(1234567.89);
    assert(
      'Format INR',
      'Formats 12.34 Lakhs correctly',
      f2 === '₹12,34,567.89',
      '₹12,34,567.89',
      f2
    );
  }

  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;

  return {
    total: results.length,
    passed,
    failed,
    results,
  };
}
